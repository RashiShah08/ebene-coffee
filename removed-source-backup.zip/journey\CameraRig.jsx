import { useRef } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { getState } from '../store'
import { CAMERA_KEYS, smooth } from './config'

const pos = new THREE.Vector3()
const look = new THREE.Vector3()
const a = new THREE.Vector3()
const b = new THREE.Vector3()

function sample(p, out, key) {
  let i = 0
  while (i < CAMERA_KEYS.length - 2 && CAMERA_KEYS[i + 1].p <= p) i++
  const k0 = CAMERA_KEYS[i]
  const k1 = CAMERA_KEYS[i + 1]
  const t = smooth(Math.min(1, Math.max(0, (p - k0.p) / (k1.p - k0.p))))
  a.fromArray(k0[key])
  b.fromArray(k1[key])
  out.lerpVectors(a, b, t)
}

/**
 * Scroll is the throttle. The camera lerps between keyframes with an eased
 * segment each, then pointer parallax and a breathing sway are layered on so
 * the flight never feels like it's on rails even though it absolutely is.
 */
export function CameraRig() {
  const sway = useRef({ x: 0, y: 0 })

  useFrame((state) => {
    const { scroll, pointer, scrollVelocity } = getState()
    const t = state.clock.elapsedTime
    const cam = state.camera

    sample(scroll, pos, 'pos')
    sample(scroll, look, 'look')

    // parallax eases toward the pointer, never snaps
    sway.current.x += (pointer.x * 0.5 - sway.current.x) * 0.04
    sway.current.y += (pointer.y * 0.3 - sway.current.y) * 0.04

    cam.position.set(
      pos.x + sway.current.x + Math.sin(t * 0.5) * 0.05,
      pos.y + sway.current.y + Math.cos(t * 0.4) * 0.04,
      pos.z
    )
    cam.lookAt(look.x, look.y, look.z)

    // scroll speed leans the horizon a touch — pure drama
    cam.rotation.z += THREE.MathUtils.clamp(scrollVelocity * 0.0004, -0.05, 0.05)
  })

  return null
}
