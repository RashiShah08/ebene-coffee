import { order } from './content'

/** Pounds → "4.80". One place, so a price never renders as "4.8" anywhere. */
export const gbp = (n) => n.toFixed(2)

const deltaOf = (table, id) => table.find((o) => o.id === id)?.delta ?? 0

/** Unit price for one drink with its modifiers applied. */
export function linePrice(basePrice, size, milk) {
  return Number(basePrice) + deltaOf(order.sizes, size) + deltaOf(order.milks, milk)
}

/** Whether a drink takes a milk choice at all. */
export const takesMilk = (kind) => !order.milkless.includes(kind)

/**
 * Order totals.
 *
 * Loyalty is one free drink per ten, and it discounts the *cheapest* line —
 * the generous reading of "every 10th is on us" would be to comp the dearest,
 * but every loyalty scheme in the world does it this way and quietly pretending
 * otherwise would be the surprising choice.
 */
export function totals(cart) {
  const count = cart.reduce((n, l) => n + l.qty, 0)
  const subtotal = cart.reduce((n, l) => n + l.unit * l.qty, 0)

  const free = Math.floor(count / 10)
  const cheapest = cart.length ? Math.min(...cart.map((l) => l.unit)) : 0
  const discount = free * cheapest

  return { count, subtotal, free, discount, total: Math.max(0, subtotal - discount) }
}
