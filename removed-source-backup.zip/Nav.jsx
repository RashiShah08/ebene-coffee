import { useEffect, useRef } from 'react'
import { brand } from '../content'
import { useStore, getState } from '../store'
import { getLenis } from '../hooks/useLenis'
import { CHAPTERS } from '../journey/config'

/** Scroll the journey to a progress value (0..1). */
export function flyTo(p, duration = 2.4) {
  const max = document.documentElement.scrollHeight - window.innerHeight
  const lenis = getLenis()
  if (lenis) lenis.scrollTo(max * p, { duration })
  else window.scrollTo({ top: max * p, behavior: 'smooth' })
}

/**
 * Brand top-left, order button top-right, and the flight plan down the right
 * edge: one dot per chapter plus a progress thread showing how deep in you are.
 */
export function Nav() {
  const cart = useStore((s) => s.cart)
  const setCartOpen = useStore((s) => s.setCartOpen)
  const count = cart.reduce((n, l) => n + l.qty, 0)

  const threadRef = useRef(null)
  const dotsRef = useRef([])

  useEffect(() => {
    let raf = 0
    const loop = () => {
      const p = getState().scroll
      if (threadRef.current) threadRef.current.style.transform = `scaleY(${p})`
      dotsRef.current.forEach((d, i) => {
        if (!d) return
        const c = CHAPTERS[i]
        d.dataset.on = p >= c.start && p < c.end + 0.0001 ? 'true' : 'false'
      })
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [])

  return (
    <>
      <header className="nav">
        <button className="nav__brand" onClick={() => flyTo(0)}>
          {brand.name} <span>{brand.suffix}</span>
        </button>
        <button className="nav__order" onClick={() => setCartOpen(true)}>
          Order{count > 0 && <span className="nav__count">{count}</span>}
        </button>
      </header>

      <nav className="rail" aria-label="Journey chapters">
        <span className="rail__track">
          <span className="rail__thread" ref={threadRef} />
        </span>
        {CHAPTERS.map((c, i) => (
          <button
            key={c.id}
            ref={(el) => (dotsRef.current[i] = el)}
            className="rail__dot"
            onClick={() => flyTo(c.start + 0.005)}
          >
            <i />
            <span>{c.label}</span>
          </button>
        ))}
      </nav>
    </>
  )
}
