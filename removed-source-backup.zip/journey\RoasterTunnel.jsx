import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { emberVertex, emberFragment } from './journeyShaders'
import { steelMaps } from './materials'
import { getState } from '../store'
import { seg, WORLD } from './config'

const EMBERS = 900

/**
 * The roaster drum, experienced from the inside. A long ribbed cylinder the
 * camera flies through while embers stream past. Glowing rings pulse like
 * heating elements; a hot core light waits at the far end.
 */
export function RoasterTunnel() {
  const emberU = useRef(null)
  const ringMats = useRef([])
  const coreLight = useRef(null)

  const { from, to, radius } = WORLD.tunnel
  const length = from - to // positive
  const mid = (from + to) / 2

  const emberGeo = useMemo(() => {
    let s = 987654
    const rand = () => ((s = (s * 16807) % 2147483647), (s - 1) / 2147483646)
    const pos = new Float32Array(EMBERS * 3)
    const seed = new Float32Array(EMBERS)
    for (let i = 0; i < EMBERS; i++) {
      const ang = rand() * Math.PI * 2
      const rad = 0.3 + Math.pow(rand(), 0.6) * (radius - 0.6)
      pos[i * 3 + 0] = Math.cos(ang) * rad
      pos[i * 3 + 1] = Math.sin(ang) * rad
      pos[i * 3 + 2] = to - 8 // all spawn at the far mouth; the shader streams them forward
      seed[i] = rand()
    }
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
    g.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1))
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0, mid), length)
    return g
  }, [length, mid, radius, to])

  const emberUniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uSize: { value: 2.2 },
      uColor: { value: new THREE.Color('#ff7a2a') },
      uIntensity: { value: 0 },
    }),
    []
  )

  const rings = useMemo(() => {
    const out = []
    for (let z = from - 2; z > to + 1; z -= 3.2) out.push(z)
    return out
  }, [from, to])

  useFrame((state) => {
    const { scroll } = getState()
    const t = state.clock.elapsedTime

    // only burn while the camera is anywhere near the drum
    const heat = seg(scroll, 0.38, 0.46) * (1 - seg(scroll, 0.58, 0.64))

    emberUniforms.uTime.value = t
    emberUniforms.uIntensity.value = heat

    ringMats.current.forEach((m, i) => {
      if (!m) return
      const pulse = 0.55 + 0.45 * Math.sin(t * 2.2 + i * 0.9)
      m.emissiveIntensity = heat * (0.45 + pulse * 0.65)
    })

    if (coreLight.current) coreLight.current.intensity = heat * 14
  })

  return (
    <group>
      {/* the drum wall, seen from inside */}
      <mesh position={[0, 0, mid]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[radius, radius, length + 6, 48, 1, true]} />
        <meshStandardMaterial
          map={steelMaps().map}
          roughnessMap={steelMaps().rough}
          roughness={1}
          metalness={0.75}
          side={THREE.BackSide}
        />
      </mesh>

      {/* heating rings */}
      {rings.map((z, i) => (
        <mesh key={z} position={[0, 0, z]}>
          <torusGeometry args={[radius - 0.12, 0.07, 10, 64]} />
          <meshStandardMaterial
            ref={(m) => (ringMats.current[i] = m)}
            color="#241206"
            emissive="#ff6a1e"
            emissiveIntensity={0}
            roughness={0.6}
          />
        </mesh>
      ))}

      {/* embers streaming past the camera */}
      <points geometry={emberGeo} frustumCulled={false}>
        <shaderMaterial
          ref={emberU}
          vertexShader={emberVertex}
          fragmentShader={emberFragment}
          uniforms={emberUniforms}
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>

      {/* the furnace glow at the far mouth */}
      <pointLight ref={coreLight} position={[0, 0, to - 4]} color="#ff7a2a" intensity={0} distance={40} decay={2} />
    </group>
  )
}
