import { useEffect } from 'react'
import { useStore } from '../store'

/**
 * Global pointer tracking. Feeds camera parallax and the bean cursor.
 * Velocity is measured per-event and decayed, so a flick reads as a spin
 * on the cursor bean even after the pointer stops.
 */
export function usePointer() {
  const setPointer = useStore((s) => s.setPointer)
  const pulseClick = useStore((s) => s.pulseClick)
  const touch = useStore((s) => s.touch)

  useEffect(() => {
    if (touch) return

    let lastX = window.innerWidth / 2
    let lastY = window.innerHeight / 2
    let vx = 0
    let vy = 0
    let raf = 0

    const onMove = (e) => {
      vx = e.clientX - lastX
      vy = e.clientY - lastY
      lastX = e.clientX
      lastY = e.clientY
      setPointer(
        { x: (e.clientX / window.innerWidth) * 2 - 1, y: -((e.clientY / window.innerHeight) * 2 - 1) },
        { x: e.clientX, y: e.clientY },
        { x: vx, y: vy }
      )
    }

    // Decay velocity toward zero so the bean settles when the pointer rests.
    const decay = () => {
      if (Math.abs(vx) > 0.01 || Math.abs(vy) > 0.01) {
        vx *= 0.88
        vy *= 0.88
        const s = useStore.getState()
        setPointer(s.pointer, s.pointerPx, { x: vx, y: vy })
      }
      raf = requestAnimationFrame(decay)
    }
    raf = requestAnimationFrame(decay)

    window.addEventListener('pointermove', onMove, { passive: true })
    window.addEventListener('pointerdown', pulseClick)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerdown', pulseClick)
    }
  }, [setPointer, pulseClick, touch])
}
