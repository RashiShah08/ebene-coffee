import { create } from 'zustand'

/**
 * Single source of truth shared between the DOM layer and the WebGL layer.
 * Written by scroll/pointer handlers, read inside useFrame — so updates here
 * must stay cheap and allocation-free.
 */
export const useStore = create((set) => ({
  // ---- scroll ----------------------------------------------------------
  scroll: 0, // 0..1 across the whole page
  scrollVelocity: 0, // px/frame, signed — drives liquid slosh
  section: 'hero', // id of the section currently occupying the viewport
  sectionProgress: 0, // 0..1 within the active section
  setScroll: (scroll, scrollVelocity) => set({ scroll, scrollVelocity }),
  setSection: (section, sectionProgress) => set({ section, sectionProgress }),

  // ---- pointer / cursor ------------------------------------------------
  pointer: { x: 0, y: 0 }, // normalised device coords, -1..1
  pointerPx: { x: 0, y: 0 }, // raw client px, for the cursor mesh
  pointerVel: { x: 0, y: 0 },
  cursorState: 'default', // 'default' | 'hover' | 'text' | 'drag'
  cursorTarget: null, // { x, y, w, h } of the hovered element, in px
  clickPulse: 0, // incremented on every click; the cursor watches it
  setPointer: (pointer, pointerPx, pointerVel) => set({ pointer, pointerPx, pointerVel }),
  setCursorState: (cursorState, cursorTarget = null) => set({ cursorState, cursorTarget }),
  pulseClick: () => set((s) => ({ clickPulse: s.clickPulse + 1 })),

  // ---- interactive sections -------------------------------------------
  roast: 2, // index into content.roast.levels
  roastFloat: 2, // continuous value while dragging, for smooth 3D lerp
  setRoast: (roast, roastFloat) => set({ roast, roastFloat }),

  menuIndex: 0,
  menuAngle: 0, // continuous ring rotation in radians
  setMenu: (menuIndex, menuAngle) => set({ menuIndex, menuAngle }),

  // ---- the order ---------------------------------------------------------
  // Lines are keyed by name+size+milk so the same drink ordered two ways
  // stays two rows, while a repeat of an identical drink just bumps qty.
  cart: [],
  cartOpen: false,
  slot: 0, // index into content.order.slots
  placed: null, // order reference string once sent, null while composing

  addToCart: (line) =>
    set((s) => {
      const key = `${line.name}|${line.size}|${line.milk}`
      const found = s.cart.find((l) => l.key === key)
      const cart = found
        ? s.cart.map((l) => (l.key === key ? { ...l, qty: l.qty + 1 } : l))
        : [...s.cart, { ...line, key, qty: 1 }]
      // Adding always re-opens the drawer on a fresh order, never on a repeat —
      // a panel that flies in on every tap makes ordering three coffees a chore.
      return { cart, placed: null, cartOpen: s.cart.length === 0 ? true : s.cartOpen }
    }),

  setQty: (key, qty) =>
    set((s) => ({
      cart: qty <= 0 ? s.cart.filter((l) => l.key !== key) : s.cart.map((l) => (l.key === key ? { ...l, qty } : l)),
    })),

  clearCart: () => set({ cart: [], placed: null }),
  setCartOpen: (cartOpen) => set({ cartOpen }),
  setSlot: (slot) => set({ slot }),
  setPlaced: (placed) => set({ placed }),

  // ---- lifecycle -------------------------------------------------------
  loaded: true,
  // There is no preloader. A loading screen on a page with no assets to load is
  // theatre, and it puts a cheap-feeling gate in front of the first impression.
  // Kept as state because the entrance animations gate on it.
  revealed: true,
  setLoaded: (loaded) => set({ loaded }),
  setRevealed: (revealed) => set({ revealed }),

  // ---- quality ---------------------------------------------------------
  // Set automatically when the renderer can't hold frame rate. Rather than
  // guessing at the viewer's hardware, the scene measures itself and sheds
  // the expensive passes — a smooth cheap frame always looks more
  // professional than a stuttering expensive one.
  degraded: false,
  setDegraded: (degraded) => set({ degraded }),

  lite: new URLSearchParams(window.location.search).has('lite'),
  reduced: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  touch: window.matchMedia('(hover: none), (pointer: coarse)').matches,
}))

/** Non-reactive read, for use inside useFrame where subscribing would re-render. */
export const getState = useStore.getState

// Dev-only handle, so the scroll spine can be inspected from the console.
if (import.meta.env.DEV) window.__store = useStore
