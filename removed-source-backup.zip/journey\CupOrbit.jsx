import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { makeCupGeometry, makeSaucerGeometry, CUP_RIM } from '../three/geometry'
import { ceramicMaps, cremaMap } from './materials'
import { menu } from '../content'
import { getState, useStore } from '../store'
import { local, seg, smooth, WORLD } from './config'

const KIND_TO_GEO = {
  espresso: 'espresso',
  cortado: 'espresso',
  flatwhite: 'wide',
  longblack: 'tumbler',
  coldbrew: 'tumbler',
  filter: 'wide',
  latte: 'tumbler',
  affogato: 'wide',
}

/**
 * The menu as a carousel of ceramics. Eight cups on a ring around the far
 * station; scrolling through the chapter spins the ring so each drink takes
 * its turn in front of the camera. The active index is pushed to the store,
 * where the DOM card reads it.
 */
export function CupOrbit() {
  const outer = useRef(null)
  const group = useRef(null)
  const cups = useRef([])

  const items = menu.items
  const n = items.length
  const { center, radius } = WORLD.ring

  const geos = useMemo(() => {
    const cache = {}
    const liquidCache = {}
    const get = (k) => (cache[k] ||= makeCupGeometry(k))
    const getLiquid = (k) =>
      (liquidCache[k] ||= new THREE.CircleGeometry(CUP_RIM[k].radius, 64))
    const kinds = items.map((it) => KIND_TO_GEO[it.kind] || 'espresso')
    return {
      saucer: makeSaucerGeometry(),
      kinds,
      cups: kinds.map(get),
      liquids: kinds.map(getLiquid),
    }
  }, [items])

  useFrame((state) => {
    const { scroll } = getState()
    const t = state.clock.elapsedTime
    if (!group.current) return

    const lt = local(scroll, 'menu')
    // hold each drink briefly: quantise the ring's target and ease toward it
    const floatIdx = lt * (n - 1)
    const idx = Math.round(floatIdx)

    const stored = useStore.getState().menuIndex
    if (idx !== stored) useStore.getState().setMenu(idx, 0)

    // ring spins so item i sits at the near side (world +Z, toward the
    // camera) — offset a touch so the hero cup parks right of the DOM card
    const target = (floatIdx / n) * Math.PI * 2 + 0.45
    group.current.rotation.y += (target - group.current.rotation.y) * 0.08

    // gentle bob per cup + the active one leans in and grows
    cups.current.forEach((c, i) => {
      if (!c) return
      const active = 1 - Math.min(1, Math.abs(floatIdx - i))
      const s = 1.25 + smooth(active) * 0.72
      c.scale.setScalar(s)
      c.position.y = -0.7 + Math.sin(t * 1.3 + i * 1.7) * 0.07 + smooth(active) * 0.25
      c.rotation.y = -group.current.rotation.y + Math.sin(t * 0.5 + i) * 0.08
    })

    // the whole ring only exists around its chapter
    const vis = seg(scroll, 0.5, 0.56) * (1 - seg(scroll, 0.76, 0.8))
    if (outer.current) outer.current.visible = vis > 0.01
  })

  return (
    <group ref={outer} position={center}>
      <group ref={group}>
      {items.map((it, i) => {
        // +PI/2 puts item 0 on the camera side before any spin is applied
        const ang = (i / n) * Math.PI * 2 + Math.PI / 2
        return (
          <group
            key={it.name}
            ref={(el) => (cups.current[i] = el)}
            position={[Math.cos(ang) * radius, -0.7, Math.sin(ang) * radius]}
          >
            <mesh geometry={geos.cups[i]}>
              {/* glazed speckled stoneware */}
              <meshPhysicalMaterial
                map={ceramicMaps().map}
                roughnessMap={ceramicMaps().rough}
                roughness={1}
                clearcoat={0.9}
                clearcoatRoughness={0.22}
                envMapIntensity={1.1}
              />
            </mesh>
            <mesh geometry={geos.saucer} position={[0, -0.02, 0]}>
              <meshPhysicalMaterial
                map={ceramicMaps().map}
                roughnessMap={ceramicMaps().rough}
                roughness={1}
                clearcoat={0.9}
                clearcoatRoughness={0.22}
                envMapIntensity={1.1}
              />
            </mesh>
            {/* the coffee itself — crema ring, glassy surface, filled to
                this cup's own inner radius and height */}
            <mesh
              geometry={geos.liquids[i]}
              rotation={[-Math.PI / 2, 0, 0]}
              position={[0, CUP_RIM[geos.kinds[i]].y, 0]}
            >
              <meshPhysicalMaterial
                map={cremaMap()}
                roughness={0.06}
                clearcoat={1}
                clearcoatRoughness={0.05}
                envMapIntensity={1.6}
              />
            </mesh>
          </group>
        )
      })}
      </group>

      {/* Static lights — outside the spinning group so the front cup is
          always the lit one. Key from the camera side, cool top fill,
          amber kicker from below. */}
      <pointLight position={[1.5, 2.4, radius + 4.5]} intensity={38} color="#f6e9d2" distance={26} decay={1.8} />
      <pointLight position={[0, 6, 0]} intensity={26} color="#f4e8d0" distance={22} decay={1.8} />
      <pointLight position={[-2, -2.5, radius + 1]} intensity={9} color="#e08b3c" distance={12} decay={2} />
    </group>
  )
}
