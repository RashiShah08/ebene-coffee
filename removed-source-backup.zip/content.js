/**
 * Every user-facing string and data table lives here.
 * Rebranding the site = editing this file only.
 */

export const brand = {
  name: 'OBSIDIAN',
  suffix: 'Coffee Co.',
  tagline: 'Roasted Daily',
  est: '2009',
}

export const nav = [
  { label: 'Beans', href: '#origin' },
  { label: 'Roast', href: '#roast' },
  { label: 'Menu', href: '#menu' },
  { label: 'Brew', href: '#brew' },
  { label: 'Subs', href: '#subscribe' },
  { label: 'Visit', href: '#visit' },
]

/** Lines the preloader counts through while the page boots. */
export const preloader = {
  lines: ['Weighing the dose', 'Heating the group', 'Purging the wand', 'Pulling a test shot'],
  ready: 'Service',
}

/** Scrolling ticker strip under the hero. Repeats forever. */
export const marquee = [
  'ROASTED DAILY',
  'SINCE 2009',
  'SMALL BATCH',
  'DIRECT TRADE',
  'NO SYRUP, SORRY',
  'FITZROVIA, LONDON',
]

export const hero = {
  badge: 'Best cup in W1 · probably',
  eyebrow: 'Small batch roasters · Est. 2009',
  titleLines: ['ROASTED', 'DAILY'],
  body:
    'Twelve kilos at a time, logged to the second, pulled to a curve. ' +
    'We are extremely normal about coffee and completely unwilling to change.',
  cta: 'See the menu',
  ctaHref: '#menu',
  ctaAlt: 'Find us',
  ctaAltHref: '#visit',
  scrollCue: 'Keep going',
  stats: [
    { n: '12kg', k: 'Batch size' },
    { n: '3', k: 'Origins' },
    { n: '07:00', k: 'Doors open' },
  ],
}

export const origin = {
  index: '01',
  label: 'The Beans',
  title: 'Three farms.\nNo middlemen.',
  body:
    'We buy direct, at altitude, from growers we have worked with for a decade. ' +
    'Every lot is traceable to a single farm and a single harvest window.',
  regions: [
    {
      id: 'ethiopia',
      name: 'Yirgacheffe',
      country: 'Ethiopia',
      coords: '6.16° N, 38.20° E',
      altitude: '1,950 m',
      process: 'Natural, 21-day raised bed',
      notes: ['Bergamot', 'Jasmine', 'Stone fruit'],
      swatch: '#c9622a',
    },
    {
      id: 'colombia',
      name: 'Huila',
      country: 'Colombia',
      coords: '2.53° N, 75.52° W',
      altitude: '1,720 m',
      process: 'Washed, 36-hour ferment',
      notes: ['Red apple', 'Cane sugar', 'Cocoa nib'],
      swatch: '#1d6b4a',
    },
    {
      id: 'sumatra',
      name: 'Aceh Gayo',
      country: 'Sumatra',
      coords: '4.63° N, 96.83° E',
      altitude: '1,500 m',
      process: 'Wet hulled, giling basah',
      notes: ['Cedar', 'Molasses', 'Tobacco leaf'],
      swatch: '#8a4a1d',
    },
  ],
}

export const craft = {
  index: '02',
  label: 'How It Works',
  title: 'Four steps.\nNo shortcuts.',
  stages: [
    {
      n: '01',
      name: 'Harvest',
      metric: 'Picked at 22° Brix',
      body:
        'Cherries are selectively hand-picked across four passes, weeks apart. ' +
        'Only fully ripe fruit makes the lot.',
    },
    {
      n: '02',
      name: 'Roast',
      metric: '198°C · 11:40 development',
      body:
        'A twelve-kilo drum, logged to the second. We chase the curve, not the clock — ' +
        'first crack tells us when, never the timer.',
    },
    {
      n: '03',
      name: 'Grind',
      metric: '64 mm flat burr · 380 µm',
      body:
        'Ground to order, never before. Particle distribution is measured weekly ' +
        'and burrs are replaced long before they dull.',
    },
    {
      n: '04',
      name: 'Extract',
      metric: '9 bar · 93°C · 1:2.3 in 28s',
      body:
        'Pressure profiled, temperature stable to a tenth of a degree. ' +
        'Every shot is weighed in and weighed out.',
    },
  ],
}

export const roast = {
  index: '03',
  label: 'Roast Dial',
  title: 'Pick your poison.',
  body: 'Drag the dial. The bean, the numbers and the tasting notes all follow.',
  // five detents, light -> dark
  levels: [
    {
      name: 'Cinnamon',
      agtron: 78,
      temp: '196°C',
      time: '09:10',
      notes: ['Citrus peel', 'Jasmine', 'White tea'],
      body: 'Bright and unresolved. Acidity forward, almost savoury underneath.',
      color: '#B9834B',
      oil: 0.0,
    },
    {
      name: 'City',
      agtron: 66,
      temp: '204°C',
      time: '10:25',
      notes: ['Red apple', 'Honey', 'Almond'],
      body: 'The balance point. Sweetness arrives, acidity stays legible.',
      color: '#8A5630',
      oil: 0.08,
    },
    {
      name: 'Full City',
      agtron: 54,
      temp: '212°C',
      time: '11:40',
      notes: ['Cocoa nib', 'Brown sugar', 'Walnut'],
      body: 'Our house roast. Body thickens, origin character still intact.',
      color: '#5E3620',
      oil: 0.24,
    },
    {
      name: 'Vienna',
      agtron: 46,
      temp: '219°C',
      time: '12:50',
      notes: ['Dark chocolate', 'Molasses', 'Toasted oak'],
      body: 'Past second crack. Origin recedes, roast character leads.',
      color: '#3C2216',
      oil: 0.52,
    },
    {
      name: 'Obsidian',
      agtron: 34,
      temp: '226°C',
      time: '14:05',
      notes: ['Bittersweet', 'Smoke', 'Black cardamom'],
      body: 'The namesake. Oily, near-black, unapologetically heavy.',
      color: '#1E110B',
      oil: 0.85,
    },
  ],
}

export const menu = {
  index: '04',
  label: 'The Menu',
  title: 'Eight ways in.',
  body: 'Everything is pulled from the same week-old roast. Prices in pounds, obviously.',
  items: [
    {
      name: 'Espresso',
      price: '3.20',
      kind: 'espresso',
      spec: '18g in · 42g out · 28s',
      ingredients: ['Full City house blend'],
      desc: 'The reference point. Everything else on this list is a variation on it.',
      tag: 'House',
    },
    {
      name: 'Cortado',
      price: '4.10',
      kind: 'cortado',
      spec: '1:1 · 60 ml',
      ingredients: ['Double ristretto', 'Steamed whole milk'],
      desc: 'Cut, not diluted. Milk is there to round the edges and then get out of the way.',
    },
    {
      name: 'Flat White',
      price: '4.80',
      kind: 'flatwhite',
      spec: '1:3 · 160 ml',
      ingredients: ['Double ristretto', 'Microfoam'],
      desc: 'Free-poured with a rosetta we will pretend was intentional every single time.',
      tag: 'Popular',
    },
    {
      name: 'Long Black',
      price: '4.00',
      kind: 'longblack',
      spec: '1:4 · 180 ml',
      ingredients: ['Double espresso', 'Hot water, poured under'],
      desc: 'Water first, coffee after — the crema survives, the burn does not happen.',
    },
    {
      name: 'Cold Brew',
      price: '5.20',
      kind: 'coldbrew',
      spec: '18-hour steep · 1:8',
      ingredients: ['Coarse-ground Vienna', 'Filtered water', 'Ice'],
      desc: 'Slow, cold, and almost sweet. No acid burn, all body.',
    },
    {
      name: 'Filter',
      price: '4.40',
      kind: 'filter',
      spec: 'V60 · 15g:250g · 2:45',
      ingredients: ['Rotating single origin'],
      desc: 'Whatever is singing on the bar that week, brewed to show it off.',
    },
    {
      name: 'Cardamom Latte',
      price: '5.60',
      kind: 'latte',
      spec: '1:5 · 240 ml',
      ingredients: ['Double espresso', 'Milk', 'Green cardamom', 'Raw sugar'],
      desc: 'Cardamom ground in with the dose, not stirred in after. It matters.',
      tag: 'House special',
    },
    {
      name: 'Affogato',
      price: '6.40',
      kind: 'affogato',
      spec: 'One scoop · one shot',
      ingredients: ['Burnt-vanilla gelato', 'Obsidian espresso'],
      desc: 'Dessert that has to be eaten immediately, which is rather the point.',
    },
  ],
}

/* ============================================================
   Ordering
   ============================================================ */

/**
 * Modifier tables for the order drawer.
 *
 * `delta` is added to the item's base price, in pounds. Kept as numbers here
 * and formatted at the edge — money that round-trips through strings is how
 * totals end up a penny out.
 */
export const order = {
  sizes: [
    { id: 'single', label: 'Single', delta: 0 },
    { id: 'double', label: 'Double', delta: 0.7 },
  ],
  milks: [
    { id: 'whole', label: 'Whole', delta: 0 },
    { id: 'oat', label: 'Oat', delta: 0.4 },
    { id: 'none', label: 'No milk', delta: 0 },
  ],
  /** Drinks where a milk choice is meaningless. */
  milkless: ['espresso', 'longblack', 'coldbrew', 'filter'],
  slots: ['As soon as possible', 'In 15 minutes', 'In 30 minutes', 'In an hour'],
  drawer: {
    title: 'Your order',
    empty: 'Nothing in here yet. The menu is just up there.',
    emptyCta: 'Go to the menu',
    subtotal: 'Subtotal',
    loyalty: 'Loyalty (every 10th is on us)',
    total: 'Total',
    pickup: 'Pick-up',
    place: 'Place order',
    placing: 'Sending to the bar',
    doneTitle: 'On the bar.',
    doneBody: 'Give your name at the counter. We start pulling when you walk in, not before.',
    doneCta: 'Order something else',
    ref: 'Order',
  },
}

/* ============================================================
   Brew guide
   ============================================================ */

export const brew = {
  index: '05',
  label: 'Brew It Home',
  title: 'We will talk\nyou through it.',
  body:
    'Pick a method and hit start. The timer runs the real recipe — the same one ' +
    'taped inside the cupboard door behind the bar.',
  start: 'Start brewing',
  reset: 'Reset',
  stop: 'Stop',
  done: 'Drink it.',
  methods: [
    {
      id: 'v60',
      name: 'V60',
      dose: '15 g coffee · 250 g water',
      grind: 'Medium-fine · 600 µm',
      temp: '94°C',
      steps: [
        { at: 0, dur: 45, name: 'Bloom', detail: 'Pour 50 g. Swirl once. Let it breathe.' },
        { at: 45, dur: 30, name: 'First pour', detail: 'Up to 150 g in slow concentric circles.' },
        { at: 75, dur: 30, name: 'Second pour', detail: 'Up to 250 g. Keep the bed flat.' },
        { at: 105, dur: 60, name: 'Drawdown', detail: 'Hands off. Let the bed settle level.' },
      ],
    },
    {
      id: 'aeropress',
      name: 'AeroPress',
      dose: '17 g coffee · 220 g water',
      grind: 'Medium · 800 µm',
      temp: '88°C',
      steps: [
        { at: 0, dur: 20, name: 'Fill', detail: 'All 220 g at once. Inverted, cap off.' },
        { at: 20, dur: 60, name: 'Steep', detail: 'Stir three times. Cap it. Wait.' },
        { at: 80, dur: 15, name: 'Flip', detail: 'Invert onto the cup. Commit to it.' },
        { at: 95, dur: 30, name: 'Press', detail: 'Thirty seconds of steady pressure. No hero shoves.' },
      ],
    },
    {
      id: 'chemex',
      name: 'Chemex',
      dose: '30 g coffee · 500 g water',
      grind: 'Coarse · 1000 µm',
      temp: '95°C',
      steps: [
        { at: 0, dur: 45, name: 'Bloom', detail: 'Pour 90 g. Rinse the filter first — always.' },
        { at: 45, dur: 60, name: 'Build', detail: 'Up to 300 g, slow and central.' },
        { at: 105, dur: 60, name: 'Top up', detail: 'Up to 500 g. Mind the ridge.' },
        { at: 165, dur: 75, name: 'Drawdown', detail: 'Roughly four minutes total. Swirl before pouring.' },
      ],
    },
  ],
}

/* ============================================================
   Subscription
   ============================================================ */

export const subscribe = {
  index: '06',
  label: 'Standing Order',
  title: 'Beans, before\nyou run out.',
  body: 'Build it once. Change or cancel it whenever — no phone call, no retention offer.',
  cta: 'Start the subscription',
  note: 'First bag ships next working day. Skip, pause or cancel from any email.',
  perBag: 'per bag',
  perMonth: 'a month',
  saving: 'You save',
  vs: 'vs. buying it loose',
  bags: [
    { id: '250', label: '250 g', sub: 'One person, one week', price: 11.5 },
    { id: '500', label: '500 g', sub: 'Two people, or one serious one', price: 20.0 },
    { id: '1000', label: '1 kg', sub: 'An office, or no self-control', price: 36.0 },
  ],
  frequencies: [
    { id: 'weekly', label: 'Weekly', perMonth: 4.33, discount: 0.15 },
    { id: 'fortnightly', label: 'Fortnightly', perMonth: 2.17, discount: 0.1 },
    { id: 'monthly', label: 'Monthly', perMonth: 1, discount: 0.05 },
  ],
  grinds: [
    { id: 'whole', label: 'Whole bean' },
    { id: 'espresso', label: 'Espresso' },
    { id: 'filter', label: 'Filter' },
    { id: 'french', label: 'French press' },
  ],
  perks: [
    'Roasted the morning it ships',
    'Free delivery, every time',
    'Cupping invites before anyone else',
    'Pause or cancel in two clicks',
  ],
}

/* ============================================================
   Social proof + questions
   ============================================================ */

export const voices = {
  label: 'Word Of Mouth',
  title: 'People talk.',
  items: [
    {
      quote:
        'I have been coming here four years and they have never once asked if I want it to go. They know. That is the whole review.',
      name: 'Priya N.',
      role: 'Regular, table by the window',
      rating: 5,
    },
    {
      quote:
        'Asked for a caramel syrup as a joke. The silence lasted long enough that I bought a bag of beans to apologise.',
      name: 'Tom A.',
      role: 'Learned his lesson',
      rating: 5,
    },
    {
      quote:
        'The Yirgacheffe on filter genuinely tastes like a peach. I brought my dad, who says all coffee tastes the same. He has stopped saying that.',
      name: 'Dee W.',
      role: 'Subscriber since 2021',
      rating: 5,
    },
    {
      quote:
        'Best flat white in W1 and the only place where the barista remembered my order after one visit. Slightly unnerving. Great coffee.',
      name: 'Marcus L.',
      role: 'Works around the corner',
      rating: 4,
    },
  ],
}

export const faq = {
  label: 'Before You Ask',
  title: 'Fair questions.',
  items: [
    {
      q: 'Do you do decaf?',
      a: 'Yes, and we take it seriously — a Colombian sugarcane-process decaf, roasted on its own profile. It is not an afterthought and we will not make a face.',
    },
    {
      q: 'Why is there no syrup?',
      a: 'Because we roast to a curve that already tastes of chocolate and cane sugar, and pouring vanilla over it undoes eleven minutes of work. The cardamom latte is our compromise and we think it is a good one.',
    },
    {
      q: 'Can I work here all day?',
      a: 'On weekdays, gladly — there are sockets along the back wall. Weekends after midday, laptops go away. It is a small room and it should sound like one.',
    },
    {
      q: 'How fresh are the beans you sell?',
      a: 'Everything on the shelf was roasted within the last seven days, and the roast date is stamped on the bag — not a "best before" eighteen months out.',
    },
    {
      q: 'Do you take card?',
      a: 'Card, phone, watch, whatever you have. We stopped taking cash in 2021 and nobody has missed it.',
    },
    {
      q: 'Are you dog friendly?',
      a: 'Extremely. There is a water bowl by the door and a jar of biscuits behind the till that costs us more per month than the oat milk.',
    },
  ],
}

export const visit = {
  index: '07',
  label: 'Come In',
  title: 'Corner of Kiln Lane.',
  address: ['41 Kiln Lane', 'Fitzrovia, London W1T'],
  coords: '51.5194° N, 0.1350° W',
  phone: '+44 20 7946 0221',
  email: 'hello@obsidian.coffee',
  // 0 = Sunday
  hours: [
    { day: 'Mon — Thu', open: 7, close: 18, label: '07:00 — 18:00' },
    { day: 'Friday', open: 7, close: 22, label: '07:00 — 22:00' },
    { day: 'Saturday', open: 8, close: 22, label: '08:00 — 22:00' },
    { day: 'Sunday', open: 9, close: 16, label: '09:00 — 16:00' },
  ],
  note: 'No laptops after midday on weekends. Talk to each other.',
}

export const footer = {
  newsletter: {
    title: 'Get the good stuff first',
    body: 'New lots, cupping invites, and the occasional strong opinion. Monthly, never more.',
    placeholder: 'your@email.com',
    cta: 'Sign me up',
    success: 'You are in.',
  },
  socials: [
    { label: 'Instagram', href: '#' },
    { label: 'Untappd', href: '#' },
    { label: 'Journal', href: '#' },
  ],
  legal: `© ${new Date().getFullYear()} ${brand.name} ${brand.suffix}. All rights reserved.`,
  credit: 'A demonstration build. The cup up top is drawn in real time.',
}
