import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { order } from '../content'
import { useStore } from '../store'
import { gbp, totals } from '../pricing'
import { getLenis } from '../hooks/useLenis'
import { flyTo } from './Nav'
import { chapter } from '../journey/config'

const t = order.drawer

/**
 * The order drawer.
 *
 * Slides in from the right over a dimmed page. Three states share the panel —
 * empty, composing, and placed — because a separate confirmation route for a
 * four-line order would be more navigation than the task deserves.
 *
 * Body scroll is stopped through Lenis rather than by setting overflow:hidden
 * on <body>: Lenis owns the scroll position, and taking the scrollbar away
 * underneath it shifts layout and desyncs every ScrollTrigger on the page.
 */
export function OrderDrawer() {
  const cart = useStore((s) => s.cart)
  const open = useStore((s) => s.cartOpen)
  const setOpen = useStore((s) => s.setCartOpen)
  const setQty = useStore((s) => s.setQty)
  const clearCart = useStore((s) => s.clearCart)
  const slot = useStore((s) => s.slot)
  const setSlot = useStore((s) => s.setSlot)
  const placed = useStore((s) => s.placed)
  const setPlaced = useStore((s) => s.setPlaced)

  const [sending, setSending] = useState(false)
  const panelRef = useRef(null)
  const closeRef = useRef(null)

  const sums = totals(cart)

  // Freeze the page behind the drawer, and hand focus to the panel.
  useEffect(() => {
    const lenis = getLenis()
    if (open) {
      lenis?.stop()
      closeRef.current?.focus()
    } else {
      lenis?.start()
    }
  }, [open])

  // Escape closes, from anywhere.
  useEffect(() => {
    if (!open) return
    const onKey = (e) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, setOpen])

  // Each line deals itself in as it appears.
  useEffect(() => {
    if (!open || !panelRef.current) return
    const rows = panelRef.current.querySelectorAll('.oline')
    if (!rows.length) return
    gsap.fromTo(
      rows,
      { opacity: 0, x: 30 },
      { opacity: 1, x: 0, duration: 0.5, ease: 'expo.out', stagger: 0.05 }
    )
  }, [open, cart.length])

  const place = () => {
    setSending(true)
    // A beat of latency. Instant success on a fake transaction reads as a
    // button that did nothing.
    setTimeout(() => {
      setSending(false)
      setPlaced(`OB-${Math.floor(1000 + Math.random() * 9000)}`)
    }, 1100)
  }

  const startOver = () => {
    clearCart()
    setOpen(false)
  }

  return (
    <div className="drawer" data-open={open}>
      <button
        className="drawer__scrim"
        aria-label="Close order"
        tabIndex={open ? 0 : -1}
        onClick={() => setOpen(false)}
      />

      <aside
        className="drawer__panel"
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label={t.title}
        aria-hidden={!open}
      >
        <header className="drawer__head">
          <h2 className="drawer__title">{placed ? t.doneTitle : t.title}</h2>
          <button
            className="drawer__close"
            onClick={() => setOpen(false)}
            ref={closeRef}
            tabIndex={open ? 0 : -1}
            aria-label="Close order"
          >
            ✕
          </button>
        </header>

        {/* ---- placed ---------------------------------------------------- */}
        {placed ? (
          <div className="drawer__done">
            <span className="drawer__stamp">
              {t.ref} {placed}
            </span>
            <p className="drawer__done-body">{t.doneBody}</p>
            <p className="drawer__done-slot">{order.slots[slot]}</p>
            <button className="btn btn--block" onClick={startOver} tabIndex={open ? 0 : -1}>
              {t.doneCta}
            </button>
          </div>
        ) : cart.length === 0 ? (
          /* ---- empty ---------------------------------------------------- */
          <div className="drawer__empty">
            <span className="drawer__empty-mark" aria-hidden="true">
              ○
            </span>
            <p>{t.empty}</p>
            <button
              className="btn btn--ghost"
              tabIndex={open ? 0 : -1}
              onClick={() => {
                setOpen(false)
                // fly the camera to the cup ring
                flyTo(chapter('menu').start + 0.01, 2)
              }}
            >
              {t.emptyCta}
            </button>
          </div>
        ) : (
          /* ---- composing ------------------------------------------------ */
          <>
            <ul className="drawer__lines">
              {cart.map((l) => (
                <li className="oline" key={l.key}>
                  <div className="oline__main">
                    <span className="oline__name">{l.name}</span>
                    <span className="oline__mods">
                      {l.sizeLabel}
                      {l.milkLabel ? ` · ${l.milkLabel}` : ''}
                    </span>
                  </div>

                  <div className="oline__qty">
                    <button
                      onClick={() => setQty(l.key, l.qty - 1)}
                      aria-label={`One fewer ${l.name}`}
                      tabIndex={open ? 0 : -1}
                    >
                      −
                    </button>
                    <span>{l.qty}</span>
                    <button
                      onClick={() => setQty(l.key, l.qty + 1)}
                      aria-label={`One more ${l.name}`}
                      tabIndex={open ? 0 : -1}
                    >
                      +
                    </button>
                  </div>

                  <span className="oline__price">£{gbp(l.unit * l.qty)}</span>
                </li>
              ))}
            </ul>

            <div className="drawer__slots">
              <span className="label">{t.pickup}</span>
              <div className="drawer__slot-row">
                {order.slots.map((s, i) => (
                  <button
                    key={s}
                    className="chip"
                    data-on={i === slot}
                    onClick={() => setSlot(i)}
                    tabIndex={open ? 0 : -1}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="drawer__sums">
              <div className="drawer__sum">
                <span>{t.subtotal}</span>
                <span>£{gbp(sums.subtotal)}</span>
              </div>
              {sums.free > 0 && (
                <div className="drawer__sum drawer__sum--free">
                  <span>{t.loyalty}</span>
                  <span>−£{gbp(sums.discount)}</span>
                </div>
              )}
              <div className="drawer__sum drawer__sum--total">
                <span>{t.total}</span>
                <span>£{gbp(sums.total)}</span>
              </div>
            </div>

            <button
              className="btn btn--block"
              onClick={place}
              disabled={sending}
              tabIndex={open ? 0 : -1}
            >
              {sending ? t.placing : t.place}
              <span aria-hidden="true">{sending ? '…' : '→'}</span>
            </button>
          </>
        )}
      </aside>
    </div>
  )
}
