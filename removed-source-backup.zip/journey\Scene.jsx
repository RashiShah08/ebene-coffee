import { Canvas } from '@react-three/fiber'
import { Environment, Lightformer } from '@react-three/drei'
import { EffectComposer, Bloom, Vignette, Noise, ChromaticAberration } from '@react-three/postprocessing'
import { BlendFunction } from 'postprocessing'
import * as THREE from 'three'
import { useStore } from '../store'
import { PALETTE } from './config'
import { CameraRig } from './CameraRig'
import { BeanField } from './BeanField'
import { RoasterTunnel } from './RoasterTunnel'
import { CupOrbit } from './CupOrbit'
import { PourWipe } from './PourWipe'
import { Finale } from './Finale'
import { Atmosphere } from './Atmosphere'

/**
 * The fixed, full-viewport WebGL layer. Everything the site *is* lives in
 * here; the DOM on top is captions.
 */
export function Scene() {
  const lite = useStore((s) => s.lite)

  return (
    <div className="gl" aria-hidden="true">
      <Canvas
        dpr={[1, 1.75]}
        gl={{ antialias: true, powerPreference: 'high-performance' }}
        camera={{ fov: 62, near: 0.1, far: 240, position: [0.55, 0.4, 5.6] }}
      >
        <color attach="background" args={[PALETTE.bg]} />
        <fog attach="fog" args={[PALETTE.bg, 10, 62]} />

        {/* A studio built from light panels, baked to a local cubemap — real
            reflections on glaze, oil and crema without fetching an HDRI. */}
        <Environment resolution={128} frames={1}>
          <Lightformer intensity={2.2} color="#f6e3c2" position={[0, 6, 4]} scale={[14, 5, 1]} rotation={[-0.6, 0, 0]} />
          <Lightformer intensity={0.9} color="#e08b3c" position={[-7, 1, -2]} scale={[3, 9, 1]} rotation={[0, 1.2, 0]} />
          <Lightformer intensity={0.6} color="#9fb4cc" position={[7, -1, -3]} scale={[3, 10, 1]} rotation={[0, -1.2, 0]} />
          <Lightformer intensity={0.35} color="#f2ddba" position={[0, -6, 2]} scale={[12, 3, 1]} rotation={[1.2, 0, 0]} />
        </Environment>

        <CameraRig />
        <Atmosphere />
        <BeanField />
        <RoasterTunnel />
        <CupOrbit />
        <Finale />
        <PourWipe />

        {!lite && (
          <EffectComposer multisampling={4}>
            <Bloom mipmapBlur intensity={0.85} luminanceThreshold={0.76} luminanceSmoothing={0.3} />
            {/* Barely-there lens fringing and grain. Both are under the
                threshold of "did you do something" on purpose — they exist to
                stop the render reading as clean synthetic CG. */}
            <ChromaticAberration offset={new THREE.Vector2(0.0007, 0.0009)} radialModulation modulationOffset={0.35} />
            <Noise premultiply blendFunction={BlendFunction.OVERLAY} opacity={0.32} />
            <Vignette eskil={false} offset={0.14} darkness={0.92} />
          </EffectComposer>
        )}
      </Canvas>
    </div>
  )
}
