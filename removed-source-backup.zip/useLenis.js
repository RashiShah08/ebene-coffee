import { useEffect } from 'react'
import Lenis from 'lenis'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useStore } from '../store'

gsap.registerPlugin(ScrollTrigger)

let lenis = null
export const getLenis = () => lenis

/**
 * Smooth scroll singleton. Lenis drives GSAP's ticker, and ScrollTrigger is
 * updated from Lenis' scroll event — so DOM animation and the R3F camera all
 * read from exactly one scroll value and can never disagree.
 */
export function useLenis() {
  const reduced = useStore((s) => s.reduced)
  const lite = useStore((s) => s.lite)
  const setScroll = useStore((s) => s.setScroll)

  useEffect(() => {
    // ?p=0.45 freezes the journey at that progress — deep links, debugging,
    // and screenshot rigs all use it. No scroll wiring at all in this mode.
    const frozen = parseFloat(new URLSearchParams(window.location.search).get('p'))
    if (!Number.isNaN(frozen)) {
      setScroll(Math.min(1, Math.max(0, frozen)), 0)
      return
    }

    // Lite mode drops smooth scrolling along with everything else expensive.
    // It also restores native anchor jumps, which Lenis otherwise swallows —
    // handy when you need to land directly on a section.
    if (reduced || lite) {
      // Native scrolling, but ScrollTrigger still needs the page progress.
      const onScroll = () => {
        const max = document.documentElement.scrollHeight - window.innerHeight
        setScroll(max > 0 ? window.scrollY / max : 0, 0)
      }
      onScroll()
      window.addEventListener('scroll', onScroll, { passive: true })
      return () => window.removeEventListener('scroll', onScroll)
    }

    lenis = new Lenis({
      lerp: 0.08,
      wheelMultiplier: 0.9,
      smoothWheel: true,
      syncTouch: false,
    })

    lenis.on('scroll', ScrollTrigger.update)

    // The store's scroll value is read from window.scrollY rather than from
    // Lenis' event payload. Lenis scrolls the window for real, so this is the
    // same number ScrollTrigger reads — which means the DOM and the camera
    // physically cannot disagree, no matter what moved the page (a nav anchor,
    // the keyboard, browser find, a programmatic jump).
    let lastY = window.scrollY
    const raf = (time) => {
      lenis.raf(time * 1000)
      const y = window.scrollY
      const max = document.documentElement.scrollHeight - window.innerHeight
      setScroll(max > 0 ? y / max : 0, y - lastY)
      lastY = y
    }
    gsap.ticker.add(raf)
    gsap.ticker.lagSmoothing(0)

    // Deliberately no ScrollTrigger.scrollerProxy here. Lenis scrolls the
    // window for real rather than transforming a wrapper, so ScrollTrigger's
    // default window scroller is already correct. Adding a proxy makes it read
    // Lenis' internal value instead, which drifts from the real scroll
    // position and silently freezes every section's progress at 0.
    return () => {
      gsap.ticker.remove(raf)
      lenis.destroy()
      lenis = null
    }
  }, [reduced, lite, setScroll])
}
