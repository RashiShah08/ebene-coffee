import * as THREE from 'three'

/**
 * Procedural coffee bean.
 *
 * Long axis = X, width = Y, thickness = Z (the flat faces point along ±Z).
 * Built from a sphere, squashed to an ellipsoid, tapered toward the ends,
 * then grooved along Y=0 with a gaussian so both flat faces carry the crease.
 * The groove is deeper on -Z, matching the flat/domed asymmetry of a real bean.
 */
export function makeBeanGeometry(segments = 48) {
  const geo = new THREE.SphereGeometry(1, segments, Math.round(segments * 0.7))
  const pos = geo.attributes.position

  const CREASE_SIGMA = 0.30
  const CREASE_FRONT = 0.88 // deep groove on the flat face — this faces +Z
  const CREASE_BACK = 0.30 // shallower on the domed face

  for (let i = 0; i < pos.count; i++) {
    let x = pos.getX(i)
    let y = pos.getY(i)
    let z = pos.getZ(i)

    // Ellipsoid proportions. Flatter and narrower than a first guess suggests
    // — a bean modelled at anything close to spherical reads as an egg no
    // matter how good the crease is.
    x *= 1.0
    y *= 0.66
    z *= 0.42

    // taper: pinch the width and thickness toward the tips of the long axis
    const taper = 1 - 0.28 * x * x
    y *= taper
    z *= taper

    // crease: a gaussian valley running the length of the bean at y = 0
    const g = Math.exp(-(y * y) / (CREASE_SIGMA * CREASE_SIGMA))
    // Deep side faces +Z, which is the side that faces the camera in the
    // roast section. A bean whose crease points away is just an egg.
    const depth = z > 0 ? CREASE_FRONT : CREASE_BACK
    // fade the groove out near the tips so it doesn't cut through them
    const along = 1 - Math.pow(Math.abs(x), 3)
    z *= 1 - depth * g * Math.max(0, along)

    pos.setXYZ(i, x, y, z)
  }

  geo.computeVertexNormals()
  geo.computeBoundingSphere()
  return geo
}

/**
 * Half a bean, cut along its crease.
 *
 * Built as real geometry rather than by clipping the whole bean at render
 * time: material clipping planes depend on renderer.localClippingEnabled and
 * fail silently — invisible mesh, no warning — if that flag doesn't take.
 * Vertices on the wrong side are collapsed onto the cut plane, which leaves a
 * flat face exactly where a split bean would have one.
 *
 * @param sign +1 keeps the +Y half, -1 keeps the -Y half.
 */
export function makeBeanHalfGeometry(sign = 1, segments = 36) {
  const geo = makeBeanGeometry(segments)
  const pos = geo.attributes.position
  for (let i = 0; i < pos.count; i++) {
    const y = pos.getY(i)
    if (sign > 0 ? y < 0 : y > 0) pos.setY(i, 0)
  }
  pos.needsUpdate = true
  geo.computeVertexNormals()
  geo.computeBoundingSphere()
  return geo
}

/**
 * Resample a profile polyline through a Catmull-Rom spline.
 *
 * Lathe geometry shades flat between rings, so a profile written as a dozen
 * control points bands visibly once a clearcoat is on it — you can count the
 * points down the side of the cup. Splining to ~8 samples per span keeps the
 * silhouette the control points describe while giving normals enough rings to
 * average into a smooth wall.
 */
function smoothProfile(points, per = 8) {
  const at = (i) => points[Math.min(points.length - 1, Math.max(0, i))]
  const out = []
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = at(i - 1)
    const p1 = at(i)
    const p2 = at(i + 1)
    const p3 = at(i + 2)
    for (let s = 0; s < per; s++) {
      const t = s / per
      const t2 = t * t
      const t3 = t2 * t
      // standard Catmull-Rom basis, applied per component
      const c = (a, b, c2, d) =>
        0.5 * (2 * b + (c2 - a) * t + (2 * a - 5 * b + 4 * c2 - d) * t2 + (-a + 3 * b - 3 * c2 + d) * t3)
      out.push(new THREE.Vector2(c(p0[0], p1[0], p2[0], p3[0]), c(p0[1], p1[1], p2[1], p3[1])))
    }
  }
  const last = points[points.length - 1]
  out.push(new THREE.Vector2(last[0], last[1]))
  return out
}

/**
 * Where the coffee sits in each cup: the inner-wall radius and the height the
 * liquid surface is filled to. Read from the profiles below — a single shared
 * disc cannot serve all three, it slices out through the wall of the tall one
 * and floats in a moat inside the wide one.
 */
export const CUP_RIM = {
  espresso: { radius: 0.405, y: 0.63 },
  tumbler: { radius: 0.365, y: 1.02 },
  wide: { radius: 0.545, y: 0.60 },
}

/**
 * Cup profile for LatheGeometry — a thrown-ceramic silhouette with a
 * slight belly, a foot, and a rolled rim. Units are roughly cm/10.
 */
export function makeCupGeometry(kind = 'espresso') {
  const profiles = {
    // [radius, height] pairs, bottom to top
    espresso: [
      [0, 0], [0.34, 0], [0.36, 0.03], [0.30, 0.06],
      [0.34, 0.18], [0.40, 0.38], [0.44, 0.62], [0.46, 0.80],
      [0.47, 0.86], [0.45, 0.88], [0.43, 0.86], [0.42, 0.30], [0.41, 0.06], [0, 0.06],
    ],
    tumbler: [
      [0, 0], [0.36, 0], [0.38, 0.04], [0.34, 0.08],
      [0.36, 0.30], [0.38, 0.70], [0.40, 1.10], [0.41, 1.28],
      [0.42, 1.34], [0.40, 1.36], [0.385, 1.32], [0.375, 0.30], [0.37, 0.08], [0, 0.08],
    ],
    wide: [
      [0, 0], [0.30, 0], [0.32, 0.03], [0.27, 0.06],
      [0.36, 0.16], [0.50, 0.38], [0.58, 0.58], [0.61, 0.70],
      [0.62, 0.75], [0.60, 0.77], [0.58, 0.74], [0.56, 0.24], [0.52, 0.07], [0, 0.07],
    ],
  }

  const geo = new THREE.LatheGeometry(smoothProfile(profiles[kind] || profiles.espresso), 128)
  geo.computeVertexNormals()
  return geo
}

/** Saucer for the hero cup. */
export function makeSaucerGeometry() {
  const pts = [
    [0, 0], [0.62, 0], [0.66, 0.012], [0.70, 0.05], [0.72, 0.075],
    [0.70, 0.082], [0.64, 0.045], [0.30, 0.022], [0.28, 0.05], [0.26, 0.05], [0.24, 0.018], [0, 0.014],
  ]
  const geo = new THREE.LatheGeometry(smoothProfile(pts), 128)
  geo.computeVertexNormals()
  return geo
}

/** Cherry-branch-ish cluster used in the Craft/Harvest panel. */
export function makeCherryPositions(count = 9) {
  const out = []
  for (let i = 0; i < count; i++) {
    const t = i / (count - 1)
    const angle = t * Math.PI * 3.1
    out.push([
      Math.cos(angle) * (0.16 + t * 0.1),
      0.55 - t * 1.1,
      Math.sin(angle) * (0.16 + t * 0.1),
    ])
  }
  return out
}

/** Shared singletons — these geometries are used in several places. */
let _bean = null
export const beanGeometry = () => (_bean ||= makeBeanGeometry(40))

let _beanLow = null
export const beanGeometryLow = () => (_beanLow ||= makeBeanGeometry(20))
