/* eslint-disable */
/**
 * GLSL used across the scene. Everything shares one noise implementation so
 * the steam, the liquid surface and the pour transition all wobble with the
 * same visual grammar.
 */

export const NOISE = /* glsl */ `
vec3 mod289(vec3 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 mod289(vec4 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 permute(vec4 x){return mod289(((x*34.0)+1.0)*x);}
vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}

float snoise(vec3 v){
  const vec2 C = vec2(1.0/6.0, 1.0/3.0);
  const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
  vec3 i  = floor(v + dot(v, C.yyy));
  vec3 x0 = v - i + dot(i, C.xxx);
  vec3 g = step(x0.yzx, x0.xyz);
  vec3 l = 1.0 - g;
  vec3 i1 = min(g.xyz, l.zxy);
  vec3 i2 = max(g.xyz, l.zxy);
  vec3 x1 = x0 - i1 + C.xxx;
  vec3 x2 = x0 - i2 + C.yyy;
  vec3 x3 = x0 - D.yyy;
  i = mod289(i);
  vec4 p = permute(permute(permute(
             i.z + vec4(0.0, i1.z, i2.z, 1.0))
           + i.y + vec4(0.0, i1.y, i2.y, 1.0))
           + i.x + vec4(0.0, i1.x, i2.x, 1.0));
  float n_ = 0.142857142857;
  vec3 ns = n_ * D.wyz - D.xzx;
  vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
  vec4 x_ = floor(j * ns.z);
  vec4 y_ = floor(j - 7.0 * x_);
  vec4 x = x_ * ns.x + ns.yyyy;
  vec4 y = y_ * ns.x + ns.yyyy;
  vec4 h = 1.0 - abs(x) - abs(y);
  vec4 b0 = vec4(x.xy, y.xy);
  vec4 b1 = vec4(x.zw, y.zw);
  vec4 s0 = floor(b0) * 2.0 + 1.0;
  vec4 s1 = floor(b1) * 2.0 + 1.0;
  vec4 sh = -step(h, vec4(0.0));
  vec4 a0 = b0.xzyw + s0.xzyw * sh.xxyy;
  vec4 a1 = b1.xzyw + s1.xzyw * sh.zzww;
  vec3 p0 = vec3(a0.xy, h.x);
  vec3 p1 = vec3(a0.zw, h.y);
  vec3 p2 = vec3(a1.xy, h.z);
  vec3 p3 = vec3(a1.zw, h.w);
  vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
  p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
  vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
  m = m * m;
  return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
}

float fbm(vec3 p){
  float v = 0.0;
  float a = 0.5;
  for(int i = 0; i < 4; i++){
    v += a * snoise(p);
    p *= 2.02;
    a *= 0.5;
  }
  return v;
}
`

/* ------------------------------------------------------------------ steam */
/* Billboarded ribbons. Noise scrolls upward, thins with height, and gets a
   soft horizontal falloff so the edges never show the quad. */

export const steamVertex = /* glsl */ `
varying vec2 vUv;
uniform float uTime;
uniform float uSway;
void main(){
  vUv = uv;
  vec3 p = position;
  // lazy S-curve drift, stronger the higher up the ribbon we are
  float h = uv.y;
  p.x += sin(uTime * 0.55 + h * 3.0) * uSway * h * h;
  p.z += cos(uTime * 0.41 + h * 2.4) * uSway * 0.6 * h * h;
  p.x *= 1.0 + h * 1.35;   // widen as it rises
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
}
`

export const steamFragment = /* glsl */ `
${NOISE}
varying vec2 vUv;
uniform float uTime;
uniform float uOpacity;
uniform float uSeed;
uniform vec3  uColor;

void main(){
  vec2 uv = vUv;

  // vertical scroll + slow curl
  vec3 q = vec3(uv.x * 2.6, uv.y * 1.5 - uTime * 0.34, uSeed);
  float n = fbm(q);
  float n2 = fbm(q * 2.1 + vec3(0.0, -uTime * 0.18, 4.7));

  float wisp = smoothstep(0.05, 0.75, n * 0.6 + n2 * 0.4 + 0.35);

  // fade in from the cup, out toward the top
  float rise = smoothstep(0.0, 0.22, uv.y) * (1.0 - smoothstep(0.42, 1.0, uv.y));
  // soft edges left/right
  float edge = smoothstep(0.0, 0.32, uv.x) * (1.0 - smoothstep(0.68, 1.0, uv.x));

  float a = wisp * rise * edge * uOpacity;
  if (a < 0.002) discard;

  gl_FragColor = vec4(uColor, a);
}
`

/* ------------------------------------------------------------- light shaft */
/* A cone rendered additively. Density falls off from the axis and with
   distance, and dust noise breaks up the banding. */

export const shaftVertex = /* glsl */ `
varying vec2 vUv;
varying vec3 vPos;
varying vec3 vNormalV;
varying vec3 vViewPos;
void main(){
  vUv = uv;
  vPos = position;
  vNormalV = normalize(normalMatrix * normal);
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  vViewPos = mv.xyz;
  gl_Position = projectionMatrix * mv;
}
`

export const shaftFragment = /* glsl */ `
${NOISE}
varying vec2 vUv;
varying vec3 vPos;
varying vec3 vNormalV;
varying vec3 vViewPos;
uniform float uTime;
uniform float uIntensity;
uniform vec3  uColor;

void main(){
  // uv.y runs from base (0) to apex (1)
  float along = vUv.y;

  // brightest at the apex, fading as the beam spreads
  float fall = pow(along, 1.9);

  // Radial softness derived from how square-on we are to the surface, not
  // from uv.x — a UV-based falloff bakes a bright stripe into the geometry
  // that then rotates with it. This stays correct from every angle: dense
  // through the middle of the beam, feathered at the silhouette.
  float facing = abs(dot(normalize(vNormalV), normalize(-vViewPos)));
  float radial = pow(facing, 1.5);

  // Drifting dust. Low frequency and low contrast on purpose — crank either
  // and the cone's own triangles start showing through as a crosshatch.
  float dust = fbm(vec3(vUv.x * 2.2, vPos.y * 0.6 - uTime * 0.10, uTime * 0.04));
  dust = 0.88 + 0.12 * dust;

  float a = fall * radial * dust * uIntensity;
  gl_FragColor = vec4(uColor * a, a);
}
`

/* ----------------------------------------------------------- liquid surface */
/* Displaced disc. Ripples come from three sources: idle breathing, scroll
   velocity (slosh), and a decaying impulse when the cursor crosses it. */

export const liquidVertex = /* glsl */ `
${NOISE}
varying vec2 vUv;
varying vec3 vNormalW;
varying vec3 vPosW;
varying float vHeight;

uniform float uTime;
uniform float uSlosh;    // signed, from scroll velocity
uniform float uImpulse;  // 0..1, decays after a cursor cross
uniform vec2  uImpulsePos;

float surface(vec2 p){
  // idle breathing
  float h = snoise(vec3(p * 3.2, uTime * 0.30)) * 0.006;
  // slosh: a tilted standing wave that leans with scroll direction
  h += sin(p.x * 7.0 + uTime * 2.2) * uSlosh * 0.014;
  h += p.x * uSlosh * 0.05;
  // impulse ring expanding from where the cursor crossed
  float d = distance(p, uImpulsePos);
  h += sin(d * 26.0 - uTime * 7.0) * exp(-d * 3.4) * uImpulse * 0.02;
  return h;
}

void main(){
  vUv = uv;
  vec3 p = position;
  vec2 xz = vec2(p.x, p.y); // plane geometry lies in XY before rotation

  float h = surface(xz);
  p.z += h;
  vHeight = h;

  // analytic-ish normal from finite differences
  float e = 0.02;
  float hx = surface(xz + vec2(e, 0.0));
  float hy = surface(xz + vec2(0.0, e));
  vec3 n = normalize(vec3(-(hx - h) / e, -(hy - h) / e, 1.0));

  vNormalW = normalize(mat3(modelMatrix) * n);
  vec4 wp = modelMatrix * vec4(p, 1.0);
  vPosW = wp.xyz;

  gl_Position = projectionMatrix * viewMatrix * wp;
}
`

export const liquidFragment = /* glsl */ `
varying vec2 vUv;
varying vec3 vNormalW;
varying vec3 vPosW;
varying float vHeight;

uniform vec3  uDeep;
uniform vec3  uLight;      // key light colour
uniform vec3  uLightPos;
uniform vec3  uCamPos;
uniform float uCrema;      // 0 = black coffee, 1 = crema ring

void main(){
  vec3 N = normalize(vNormalW);
  vec3 V = normalize(uCamPos - vPosW);
  vec3 L = normalize(uLightPos - vPosW);
  vec3 H = normalize(L + V);

  // coffee is very dark and very reflective — almost all of what you see
  // is specular, which is exactly why the ripples read at all
  float spec = pow(max(dot(N, H), 0.0), 220.0) * 1.6;
  float broad = pow(max(dot(N, H), 0.0), 18.0) * 0.22;
  float fres = pow(1.0 - max(dot(N, V), 0.0), 4.0);

  vec3 col = uDeep;
  col += uLight * (spec + broad);
  col += uLight * fres * 0.30;

  // a faint crema ring toward the cup wall
  float r = length(vUv - 0.5) * 2.0;
  float ring = smoothstep(0.72, 0.99, r) * uCrema;
  col = mix(col, vec3(0.42, 0.26, 0.13), ring * 0.65);

  // let the ripple crests lift slightly, for legibility
  col += uLight * clamp(vHeight * 6.0, -0.05, 0.14);

  gl_FragColor = vec4(col, 1.0);
}
`

/* -------------------------------------------------------- pour transition */
/* Fullscreen quad. Liquid floods up from the bottom with a wobbling
   meniscus and an amber rim where the surface catches the key light. */

export const pourVertex = /* glsl */ `
varying vec2 vUv;
void main(){
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`

export const pourFragment = /* glsl */ `
${NOISE}
varying vec2 vUv;
uniform float uFill;    // 0 = empty, 1 = viewport full
uniform float uTime;
uniform vec3  uLiquid;
uniform vec3  uRim;
uniform float uAspect;

void main(){
  if (uFill <= 0.0001) discard;

  // wobbling meniscus — same noise vocabulary as the cup surface
  float w = snoise(vec3(vUv.x * 3.4, uTime * 0.9, 0.0)) * 0.018
          + snoise(vec3(vUv.x * 9.1, uTime * 1.7, 5.0)) * 0.007;

  // ease the fill so it accelerates in and drains out
  float level = uFill * 1.06 + w * smoothstep(0.02, 0.2, uFill) * (1.0 - smoothstep(0.9, 1.0, uFill));

  float d = level - vUv.y;
  if (d < 0.0) discard;

  vec3 col = uLiquid;

  // Bright meniscus, plus a wider glow bleeding below it. Without the glow the
  // liquid is almost the same value as the page background and the whole
  // effect reads as a plain fade — the moving amber edge is the only thing
  // that tells you the screen is being filled rather than dimmed.
  float rim = smoothstep(0.05, 0.0, d);
  float glow = smoothstep(0.22, 0.0, d);
  col = mix(col, uRim, rim * 0.95);
  col += uRim * glow * glow * 0.22;

  // subtle depth gradient so the mass doesn't read flat
  col *= 0.82 + 0.18 * smoothstep(0.0, 0.45, d);

  gl_FragColor = vec4(col, 1.0);
}
`

/* --------------------------------------------------------------- aroma */
/* Points shader for the roast section: rising particles whose density and
   colour follow the roast level. */

export const aromaVertex = /* glsl */ `
attribute float aSeed;
attribute float aScale;
varying float vAlpha;
uniform float uTime;
uniform float uRoast;   // 0..1
uniform float uSize;

void main(){
  vec3 p = position;

  float speed = 0.16 + aSeed * 0.14;
  float life = fract(uTime * speed + aSeed);

  p.y += life * 2.6;
  p.x += sin(uTime * 0.6 + aSeed * 12.0) * 0.13 * life;
  p.z += cos(uTime * 0.5 + aSeed * 9.0) * 0.13 * life;

  // heavier roasts sit lower and hang around longer
  p.y -= uRoast * life * 0.7;

  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_Position = projectionMatrix * mv;
  gl_PointSize = uSize * aScale * (1.0 + uRoast * 0.7) * (300.0 / -mv.z);

  vAlpha = (1.0 - life) * smoothstep(0.0, 0.12, life);
}
`

export const aromaFragment = /* glsl */ `
varying float vAlpha;
uniform vec3 uColorLight;
uniform vec3 uColorDark;
uniform float uRoast;

void main(){
  vec2 c = gl_PointCoord - 0.5;
  float d = length(c);
  if (d > 0.5) discard;
  float a = smoothstep(0.5, 0.0, d) * vAlpha;
  vec3 col = mix(uColorLight, uColorDark, uRoast);
  gl_FragColor = vec4(col, a * (0.55 + uRoast * 0.45));
}
`
