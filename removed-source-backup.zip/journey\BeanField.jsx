import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { MeshSurfaceSampler } from 'three/examples/jsm/math/MeshSurfaceSampler.js'
import { makeBeanGeometry } from '../three/geometry'
import { beanMaps } from './materials'
import { fieldVertex, fieldFragment } from './journeyShaders'
import { getState } from '../store'
import { seg, smooth, WORLD } from './config'

const COUNT = 34000
const BEAN_SCALE = 1.62

/** Deterministic pseudo-random — the field must be identical every load. */
function rng(seed) {
  let s = seed
  return () => {
    s = (s * 16807) % 2147483647
    return (s - 1) / 2147483646
  }
}

/** Terrain height: a valley running down -Z with ridges either side. */
function terrainHeight(x, z) {
  const side = Math.min(1, Math.abs(x) / 11)
  const ridges = 6.4 * side * side * (0.65 + 0.35 * Math.sin(z * 0.32 + x * 0.35))
  // Octaves, not one wobble. A single sine reads as corrugation; stacking
  // three at roughly tripling frequency is what makes it read as ground.
  const rough =
    0.85 * Math.sin(x * 0.55 + z * 0.38) * Math.sin(z * 0.47 + 1.2) +
    0.38 * Math.sin(x * 1.7 + z * 1.1) * Math.sin(z * 1.3) +
    0.16 * Math.sin(x * 4.3 + z * 3.1)
  return -3.4 + ridges + rough * (0.5 + side * 1.3)
}

/**
 * The one particle system that carries the first half of the journey:
 * bean surface → airborne debris you fly through → a mountain valley.
 */
export function BeanField() {
  const mat = useRef(null)
  const beanMat = useRef(null)
  const beanMesh = useRef(null)

  const { geometry, beanGeo } = useMemo(() => {
    const rand = rng(1234567)

    const beanGeo = makeBeanGeometry(64)
    const sampler = new MeshSurfaceSampler(new THREE.Mesh(beanGeo)).build()

    const pos = new Float32Array(COUNT * 3)
    const explode = new Float32Array(COUNT * 3)
    const terrain = new Float32Array(COUNT * 3)
    const seed = new Float32Array(COUNT)

    const v = new THREE.Vector3()
    const [zA, zB] = WORLD.terrainZ

    for (let i = 0; i < COUNT; i++) {
      // state 0 — on the bean's surface, at hero scale
      sampler.sample(v)
      pos[i * 3 + 0] = v.x * BEAN_SCALE
      pos[i * 3 + 1] = v.y * BEAN_SCALE
      pos[i * 3 + 2] = v.z * BEAN_SCALE

      // state 1 — debris strewn along the corridor between bean and valley,
      // kept off the camera's axis so the flight path stays half-clear
      const az = -3 - rand() * 26
      const ang = rand() * Math.PI * 2
      const rad = 2.6 + Math.pow(rand(), 0.7) * 8.5
      explode[i * 3 + 0] = Math.cos(ang) * rad
      explode[i * 3 + 1] = Math.sin(ang) * rad * 0.8
      explode[i * 3 + 2] = az

      // state 2 — the valley floor and its ridges. Sampling x uniformly puts
      // as much material on the empty floor as on the ridges that actually
      // carry the silhouette; biasing outward packs the slopes instead.
      const u = rand() * 2 - 1
      const tx = Math.sign(u) * Math.pow(Math.abs(u), 0.62) * 21
      const tz = zA + (zB - zA) * rand()
      terrain[i * 3 + 0] = tx
      terrain[i * 3 + 1] = terrainHeight(tx, tz)
      terrain[i * 3 + 2] = tz

      seed[i] = rand()
    }

    const geometry = new THREE.BufferGeometry()
    geometry.setAttribute('position', new THREE.BufferAttribute(pos, 3))
    geometry.setAttribute('aExplode', new THREE.BufferAttribute(explode, 3))
    geometry.setAttribute('aTerrain', new THREE.BufferAttribute(terrain, 3))
    geometry.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1))
    // The morph states span the whole corridor — never let three cull this.
    geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0, -26), 60)

    return { geometry, beanGeo }
  }, [])

  const uniforms = useMemo(
    () => ({
      uPhase: { value: 0 },
      uTime: { value: 0 },
      uSize: { value: 0.95 },
      uAlpha: { value: 0 },
      uBrown: { value: new THREE.Color('#6b4226') },
      uEmber: { value: new THREE.Color('#ff8a3d') },
      uCream: { value: new THREE.Color('#e8d3ae') },
    }),
    []
  )

  useFrame((state) => {
    const { scroll, pointer } = getState()
    const t = state.clock.elapsedTime

    // 0→1 across the shatter chapter, 1→2 while the debris settles into terrain
    const phase = seg(scroll, 0.12, 0.22) + seg(scroll, 0.22, 0.34)

    uniforms.uTime.value = t
    uniforms.uPhase.value = phase
    // hidden during the hero (the solid bean plays that part), gone again
    // once the tunnel swallows the view
    uniforms.uAlpha.value = smooth(seg(scroll, 0.115, 0.14)) * (1 - smooth(seg(scroll, 0.44, 0.5)))

    // The solid hero bean. It does NOT tumble freely: a bean is only legible
    // as a bean from the side that carries the crease, and a constant yaw
    // spends most of its cycle showing the domed back — which reads as an
    // egg. So the pose is locked crease-forward and only breathes around it.
    if (beanMesh.current) {
      const gone = smooth(seg(scroll, 0.12, 0.155))
      beanMesh.current.visible = gone < 1
      beanMesh.current.rotation.y = 0.34 + Math.sin(t * 0.26) * 0.13 + pointer.x * 0.26
      beanMesh.current.rotation.x = -0.14 + Math.sin(t * 0.19) * 0.05 + pointer.y * 0.18
      // long axis tilted off vertical — a bean squared to the frame looks like clip art
      beanMesh.current.rotation.z = -1.02
      const s = BEAN_SCALE * (1 - gone * 0.4)
      beanMesh.current.scale.setScalar(s)
      beanMat.current.opacity = 1 - gone
    }
  })

  return (
    <group>
      <mesh ref={beanMesh} geometry={beanGeo}>
        {/* roasted skin: mottled albedo, pitted bump, oily clearcoat */}
        <meshPhysicalMaterial
          ref={beanMat}
          map={beanMaps().map}
          bumpMap={beanMaps().bump}
          bumpScale={2.4}
          roughnessMap={beanMaps().rough}
          roughness={1}
          // A roasted bean is oily, not lacquered. High clearcoat on a smooth
          // ellipsoid is what makes it read as a blown-glass balloon.
          clearcoat={0.42}
          clearcoatRoughness={0.48}
          envMapIntensity={0.8}
          sheen={0.35}
          sheenRoughness={0.7}
          sheenColor="#c08a52"
          transparent
        />
      </mesh>
      <points geometry={geometry} frustumCulled={false}>
        <shaderMaterial
          ref={mat}
          vertexShader={fieldVertex}
          fragmentShader={fieldFragment}
          uniforms={uniforms}
          transparent
          depthWrite={false}
        />
      </points>
    </group>
  )
}
