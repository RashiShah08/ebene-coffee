import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { pourVertex, pourFragment } from '../three/shaders'
import { getState } from '../store'
import { seg, smooth } from './config'

/**
 * The chapter transition: coffee floods the screen bottom-up, holds for a
 * beat while the camera teleports to the finale station behind it, then the
 * level drains back down — as if the cup was drunk.
 *
 * Rendered as a clip-space quad (the vertex shader ignores the camera), so it
 * sits over everything regardless of where the rig is.
 */
export function PourWipe() {
  const mesh = useRef(null)

  const uniforms = useMemo(
    () => ({
      uFill: { value: 0 },
      uTime: { value: 0 },
      uLiquid: { value: new THREE.Color('#170b05') },
      uRim: { value: new THREE.Color('#e08b3c') },
      uAspect: { value: 1 },
    }),
    []
  )

  useFrame((state) => {
    const { scroll } = getState()
    uniforms.uTime.value = state.clock.elapsedTime
    uniforms.uAspect.value = state.size.width / state.size.height

    // flood 0.74→0.78, full through 0.795, drain 0.795→0.84
    const fill = smooth(seg(scroll, 0.74, 0.785)) * (1 - smooth(seg(scroll, 0.795, 0.845)))
    uniforms.uFill.value = fill
    if (mesh.current) mesh.current.visible = fill > 0.0005
  })

  return (
    <mesh ref={mesh} frustumCulled={false} renderOrder={999}>
      <planeGeometry args={[2, 2]} />
      <shaderMaterial
        vertexShader={pourVertex}
        fragmentShader={pourFragment}
        uniforms={uniforms}
        transparent
        depthTest={false}
        depthWrite={false}
      />
    </mesh>
  )
}
