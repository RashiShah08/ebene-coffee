/**
 * The spine of the whole site.
 *
 * The page is one continuous camera flight through a world corridor that runs
 * down -Z. Scroll progress (0..1 across the full track) is the only clock:
 * every chapter, every overlay fade and every 3D morph reads its own slice of
 * it through these ranges.
 */

/** How many viewport-heights of scroll the whole journey takes. */
export const PAGES = 12

export const CHAPTERS = [
  { id: 'hero',    label: 'Obsidian',  start: 0.0,  end: 0.12 },
  { id: 'shatter', label: 'The Break', start: 0.12, end: 0.24 },
  { id: 'origin',  label: 'Origin',    start: 0.24, end: 0.4 },
  { id: 'roast',   label: 'The Roast', start: 0.4,  end: 0.56 },
  { id: 'menu',    label: 'The Menu',  start: 0.56, end: 0.74 },
  { id: 'pour',    label: 'The Pour',  start: 0.74, end: 0.82 },
  { id: 'visit',   label: 'Visit',     start: 0.82, end: 1.0 },
]

export const chapter = (id) => CHAPTERS.find((c) => c.id === id)

/** 0..1 within a chapter, clamped. */
export function local(p, id) {
  const c = chapter(id)
  return Math.min(1, Math.max(0, (p - c.start) / (c.end - c.start)))
}

/** Remap p from [a,b] to 0..1, clamped. */
export const seg = (p, a, b) => Math.min(1, Math.max(0, (p - a) / (b - a)))

export const smooth = (t) => t * t * (3 - 2 * t)

/** World stations along the corridor (all on -Z). */
export const WORLD = {
  bean: [0, 0, 0],
  terrainZ: [-24, -52], // valley span
  tunnel: { from: -58, to: -90, radius: 3.4 },
  // Pushed right of the corridor axis: the menu card owns the lower left of
  // the frame, so the cup that steps forward has to clear it.
  ring: { center: [2.7, 0.15, -120], radius: 6, camZ: -108 },
  finale: [3.3, 0, -150], // right of centre — the visit copy owns the left
}

/**
 * Camera keyframes. Position and look-target are both lerped between
 * neighbouring keys with a smoothstep, so every segment eases without a
 * spline library. Pointer parallax is layered on top by the rig.
 */
export const CAMERA_KEYS = [
  // Look target sits left of the bean, which throws the bean into the right
  // of the frame and leaves the left clear for the wordmark. Scrolling in
  // recentres it, so the opening reads as the camera settling onto its subject.
  { p: 0.0,  pos: [0.6, 0.45, 5.2],   look: [-1.7, -0.22, 0] },
  { p: 0.12, pos: [0.0, 0.02, 3.0],   look: [0, 0, 0] },
  { p: 0.2,  pos: [0, 0.6, -6],       look: [0, 0.2, -20] },
  { p: 0.3,  pos: [0, 2.4, -20],      look: [0, -0.6, -36] },
  { p: 0.4,  pos: [0, 1.0, -44],      look: [0, 0.1, -58] },
  { p: 0.48, pos: [0, 0, -66],        look: [0, 0, -84] },
  { p: 0.56, pos: [0, 0, -92],        look: [0, 0, -108] },
  { p: 0.6,  pos: [0, 0, -108],       look: [0, 0.2, -120] },
  { p: 0.74, pos: [0, 0, -108],       look: [0, 0.2, -120] },
  // The pour wipe covers the screen across this gap — the jump to the finale
  // station happens while nothing behind it is visible.
  { p: 0.8,  pos: [0.2, 0.9, -144.5],  look: [2.1, 0.5, -150] },
  { p: 1.0,  pos: [0.7, 1.15, -145.2], look: [2.0, 0.45, -150] },
]

/** Palette shared between GLSL uniforms and CSS custom properties. */
export const PALETTE = {
  bg: '#070403',
  ink: '#f3e7d3',
  amber: '#e08b3c',
  ember: '#ff6a26',
  deep: '#120a05',
}
