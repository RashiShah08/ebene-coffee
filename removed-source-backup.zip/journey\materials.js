import * as THREE from 'three'

/**
 * Procedural PBR textures, drawn once to canvases. No image assets — the
 * realism comes from believable micro-variation: no real surface is one
 * flat colour, so none of ours are either.
 */

function canvasTexture(size, draw, { repeat = 1 } = {}) {
  const c = document.createElement('canvas')
  c.width = c.height = size
  const ctx = c.getContext('2d')
  draw(ctx, size)
  const tex = new THREE.CanvasTexture(c)
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping
  tex.repeat.set(repeat, repeat)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.anisotropy = 4
  return tex
}

/** Deterministic rand so every load looks identical. */
function rng(seed) {
  let s = seed
  return () => ((s = (s * 16807) % 2147483647), (s - 1) / 2147483646)
}

/* ------------------------------------------------------------------ bean */
/* Roasted arabica: warm umber base, oily mottle, darker pole-to-pole crease
   band (geometry puts the crease at v≈0.5), light parchment flecks where the
   silverskin clings. */

let _bean = null
export function beanMaps() {
  if (_bean) return _bean
  const rand = rng(20090401)

  const map = canvasTexture(512, (ctx, s) => {
    const g = ctx.createLinearGradient(0, 0, 0, s)
    g.addColorStop(0, '#4a2c17')
    g.addColorStop(0.5, '#3a2010')
    g.addColorStop(1, '#452a15')
    ctx.fillStyle = g
    ctx.fillRect(0, 0, s, s)

    // roast mottle — overlapping translucent blotches, dark and light
    for (let i = 0; i < 900; i++) {
      const r = 4 + rand() * 26
      const dark = rand() > 0.45
      ctx.fillStyle = dark
        ? `rgba(24, 12, 5, ${0.05 + rand() * 0.1})`
        : `rgba(122, 78, 40, ${0.04 + rand() * 0.08})`
      ctx.beginPath()
      ctx.ellipse(rand() * s, rand() * s, r, r * (0.4 + rand() * 0.6), rand() * Math.PI, 0, Math.PI * 2)
      ctx.fill()
    }

    // the crease shadow across the middle of the UV sheet
    const band = ctx.createLinearGradient(0, s * 0.38, 0, s * 0.62)
    band.addColorStop(0, 'rgba(15,7,2,0)')
    band.addColorStop(0.5, 'rgba(15,7,2,0.55)')
    band.addColorStop(1, 'rgba(15,7,2,0)')
    ctx.fillStyle = band
    ctx.fillRect(0, 0, s, s)

    // silverskin flecks caught in the crease
    for (let i = 0; i < 130; i++) {
      const y = s * (0.46 + rand() * 0.08)
      ctx.fillStyle = `rgba(214, 189, 152, ${0.12 + rand() * 0.25})`
      ctx.fillRect(rand() * s, y, 1 + rand() * 3, 1 + rand() * 1.5)
    }
  })

  const bump = canvasTexture(512, (ctx, s) => {
    ctx.fillStyle = '#808080'
    ctx.fillRect(0, 0, s, s)

    // Broad undulation first. Pits alone are sub-pixel once the bean fills the
    // frame, which leaves the surface reading as a smooth balloon no matter
    // how high bumpScale goes — the large scale is what carries the close-up.
    for (let i = 0; i < 120; i++) {
      const r = 30 + rand() * 90
      const g = ctx.createRadialGradient(0, 0, 0, 0, 0, r)
      const v = rand() > 0.5 ? 168 : 92
      g.addColorStop(0, `rgba(${v},${v},${v},0.30)`)
      g.addColorStop(1, `rgba(${v},${v},${v},0)`)
      ctx.save()
      ctx.translate(rand() * s, rand() * s)
      ctx.fillStyle = g
      ctx.fillRect(-r, -r, r * 2, r * 2)
      ctx.restore()
    }

    // mid-scale pitting — the visible craters of a roasted surface
    for (let i = 0; i < 1400; i++) {
      const r = 1.5 + rand() * 5
      const v = Math.floor(70 + rand() * 40)
      ctx.fillStyle = `rgba(${v},${v},${v},${0.3 + rand() * 0.4})`
      ctx.beginPath()
      ctx.ellipse(rand() * s, rand() * s, r, r * (0.6 + rand() * 0.5), rand() * Math.PI, 0, Math.PI * 2)
      ctx.fill()
      // lit lip on one side of each pit
      ctx.fillStyle = `rgba(190,190,190,${0.12 + rand() * 0.2})`
      ctx.beginPath()
      ctx.arc(rand() * s, rand() * s, r * 0.5, 0, Math.PI * 2)
      ctx.fill()
    }

    // fine grain
    for (let i = 0; i < 5200; i++) {
      const v = Math.floor(100 + rand() * 60)
      ctx.fillStyle = `rgb(${v},${v},${v})`
      ctx.fillRect(rand() * s, rand() * s, 1 + rand() * 2, 1 + rand() * 2)
    }
  })
  bump.colorSpace = THREE.NoColorSpace

  const rough = canvasTexture(256, (ctx, s) => {
    // oil sheen: mid roughness with glossier smears
    ctx.fillStyle = '#9a9a9a'
    ctx.fillRect(0, 0, s, s)
    for (let i = 0; i < 260; i++) {
      const v = Math.floor(70 + rand() * 60)
      ctx.fillStyle = `rgba(${v},${v},${v},0.35)`
      ctx.beginPath()
      ctx.ellipse(rand() * s, rand() * s, 6 + rand() * 30, 3 + rand() * 12, rand() * Math.PI, 0, Math.PI * 2)
      ctx.fill()
    }
  })
  rough.colorSpace = THREE.NoColorSpace

  _bean = { map, bump, rough }
  return _bean
}

/* --------------------------------------------------------------- ceramic */
/* Thrown stoneware: warm off-white glaze, iron speckle, faint throwing rings. */

let _ceramic = null
export function ceramicMaps() {
  if (_ceramic) return _ceramic
  const rand = rng(77000123)

  const map = canvasTexture(
    512,
    (ctx, s) => {
      ctx.fillStyle = '#ece2d1'
      ctx.fillRect(0, 0, s, s)

      // glaze drift
      for (let i = 0; i < 60; i++) {
        ctx.fillStyle = `rgba(${205 + Math.floor(rand() * 30)}, ${192 + Math.floor(rand() * 25)}, ${170 + Math.floor(rand() * 22)}, 0.12)`
        ctx.beginPath()
        ctx.ellipse(rand() * s, rand() * s, 40 + rand() * 120, 30 + rand() * 90, rand() * Math.PI, 0, Math.PI * 2)
        ctx.fill()
      }
      // throwing rings
      for (let y = 0; y < s; y += 3 + rand() * 6) {
        ctx.fillStyle = `rgba(120, 100, 80, ${0.015 + rand() * 0.03})`
        ctx.fillRect(0, y, s, 1)
      }
      // iron speckle
      for (let i = 0; i < 420; i++) {
        const r = 0.5 + rand() * 1.6
        ctx.fillStyle = `rgba(${60 + Math.floor(rand() * 40)}, ${44 + Math.floor(rand() * 26)}, ${30 + Math.floor(rand() * 18)}, ${0.35 + rand() * 0.5})`
        ctx.beginPath()
        ctx.arc(rand() * s, rand() * s, r, 0, Math.PI * 2)
        ctx.fill()
      }
    },
    { repeat: 2 }
  )

  const rough = canvasTexture(
    256,
    (ctx, s) => {
      ctx.fillStyle = '#4c4c4c' // glossy glaze overall
      ctx.fillRect(0, 0, s, s)
      for (let i = 0; i < 800; i++) {
        const v = Math.floor(60 + rand() * 90)
        ctx.fillStyle = `rgba(${v},${v},${v},0.5)`
        ctx.fillRect(rand() * s, rand() * s, 1 + rand() * 3, 1 + rand() * 3)
      }
    },
    { repeat: 2 }
  )
  rough.colorSpace = THREE.NoColorSpace

  _ceramic = { map, rough }
  return _ceramic
}

/* ---------------------------------------------------------------- coffee */
/* Espresso seen from above: near-black centre, tan crema ring with tiger
   flecks hugging the wall. */

let _crema = null
export function cremaMap() {
  if (_crema) return _crema
  const rand = rng(31415927)

  _crema = canvasTexture(512, (ctx, s) => {
    const cx = s / 2
    const g = ctx.createRadialGradient(cx, cx, 0, cx, cx, cx)
    g.addColorStop(0, '#1b0e06')
    g.addColorStop(0.62, '#201107') // keep dark through the middle
    g.addColorStop(0.63, '#2a1508')
    g.addColorStop(0.82, '#7a4a22')
    g.addColorStop(0.94, '#b07940')
    g.addColorStop(1, '#c58c4e')
    ctx.fillStyle = g
    ctx.fillRect(0, 0, s, s)

    // tiger-fleck the crema band
    for (let i = 0; i < 700; i++) {
      const ang = rand() * Math.PI * 2
      const rad = cx * (0.66 + rand() * 0.33)
      const x = cx + Math.cos(ang) * rad
      const y = cx + Math.sin(ang) * rad
      ctx.fillStyle =
        rand() > 0.5 ? `rgba(58, 30, 12, ${0.2 + rand() * 0.3})` : `rgba(198, 150, 96, ${0.15 + rand() * 0.3})`
      ctx.beginPath()
      ctx.ellipse(x, y, 1 + rand() * 4, 0.6 + rand() * 2, ang, 0, Math.PI * 2)
      ctx.fill()
    }

    // a lazy swirl where the pour landed
    ctx.strokeStyle = 'rgba(150, 100, 55, 0.25)'
    ctx.lineWidth = 3
    ctx.beginPath()
    for (let a = 0; a < Math.PI * 5; a += 0.1) {
      const r = 8 + a * 9
      const x = cx + Math.cos(a) * r
      const y = cx + Math.sin(a) * r * 0.9
      a === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)
    }
    ctx.stroke()
  })
  return _crema
}

/* ------------------------------------------------------------ steel drum */
/* Hot-rolled roaster steel: near-black, faintly banded, worn to bare metal
   in streaks. Used inside the tunnel. */

let _steel = null
export function steelMaps() {
  if (_steel) return _steel
  const rand = rng(66600042)

  const map = canvasTexture(
    512,
    (ctx, s) => {
      ctx.fillStyle = '#1a130c'
      ctx.fillRect(0, 0, s, s)
      // rolled bands
      for (let x = 0; x < s; x += 2 + rand() * 5) {
        ctx.fillStyle = `rgba(${30 + Math.floor(rand() * 30)}, ${22 + Math.floor(rand() * 20)}, ${14 + Math.floor(rand() * 12)}, 0.5)`
        ctx.fillRect(x, 0, 1 + rand() * 2, s)
      }
      // heat scorch blooms
      for (let i = 0; i < 40; i++) {
        const g = ctx.createRadialGradient(0, 0, 0, 0, 0, 30 + rand() * 80)
        g.addColorStop(0, `rgba(90, 45, 15, ${0.1 + rand() * 0.15})`)
        g.addColorStop(1, 'rgba(0,0,0,0)')
        ctx.save()
        ctx.translate(rand() * s, rand() * s)
        ctx.fillStyle = g
        ctx.fillRect(-120, -120, 240, 240)
        ctx.restore()
      }
    },
    { repeat: 4 }
  )

  const rough = canvasTexture(
    256,
    (ctx, s) => {
      ctx.fillStyle = '#8f8f8f'
      ctx.fillRect(0, 0, s, s)
      // worn-shiny streaks along the drum
      for (let i = 0; i < 90; i++) {
        const v = Math.floor(45 + rand() * 55)
        ctx.fillStyle = `rgba(${v},${v},${v},0.4)`
        ctx.fillRect(rand() * s, 0, 1 + rand() * 4, s)
      }
    },
    { repeat: 4 }
  )
  rough.colorSpace = THREE.NoColorSpace

  _steel = { map, rough }
  return _steel
}

/* ------------------------------------------------------------ dark timber */
/* The counter the last cup sits on. */

let _timber = null
export function timberMaps() {
  if (_timber) return _timber
  const rand = rng(19770510)

  const map = canvasTexture(512, (ctx, s) => {
    ctx.fillStyle = '#241610'
    ctx.fillRect(0, 0, s, s)
    // grain
    for (let y = 0; y < s; y += 1) {
      const wob = Math.sin(y * 0.08) * 8 + Math.sin(y * 0.023) * 20
      const v = 26 + Math.floor(14 * Math.sin(y * 0.6 + wob * 0.05)) + Math.floor(rand() * 10)
      ctx.fillStyle = `rgba(${v + 14}, ${v}, ${Math.floor(v * 0.7)}, 0.5)`
      ctx.fillRect(0, y, s, 1)
    }
    // dark knots and figure
    for (let i = 0; i < 14; i++) {
      ctx.strokeStyle = `rgba(12, 6, 3, ${0.2 + rand() * 0.3})`
      ctx.lineWidth = 1 + rand() * 3
      ctx.beginPath()
      const y0 = rand() * s
      ctx.moveTo(0, y0)
      ctx.bezierCurveTo(s * 0.3, y0 + (rand() - 0.5) * 60, s * 0.7, y0 + (rand() - 0.5) * 60, s, y0)
      ctx.stroke()
    }
  })

  const rough = canvasTexture(256, (ctx, s) => {
    ctx.fillStyle = '#5a5a5a' // oiled and buffed
    ctx.fillRect(0, 0, s, s)
    for (let y = 0; y < s; y += 2) {
      const v = Math.floor(70 + rand() * 50)
      ctx.fillStyle = `rgba(${v},${v},${v},0.4)`
      ctx.fillRect(0, y, s, 1)
    }
  })
  rough.colorSpace = THREE.NoColorSpace

  _timber = { map, rough }
  return _timber
}
