import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { dustVertex, dustFragment } from './journeyShaders'
import { steamVertex, steamFragment } from '../three/shaders'
import { getState } from '../store'
import { seg } from './config'

const DUST = 1600

/**
 * Everything that isn't a destination: the dust motes that give the flight
 * parallax, the hero's smoke wisps, and the base lighting the whole corridor
 * shares.
 */
export function Atmosphere() {
  const dustGeo = useMemo(() => {
    let s = 424242
    const rand = () => ((s = (s * 16807) % 2147483647), (s - 1) / 2147483646)
    const pos = new Float32Array(DUST * 3)
    const seed = new Float32Array(DUST)
    for (let i = 0; i < DUST; i++) {
      pos[i * 3 + 0] = (rand() * 2 - 1) * 12
      pos[i * 3 + 1] = (rand() * 2 - 1) * 8
      pos[i * 3 + 2] = 8 - rand() * 168
      seed[i] = rand()
    }
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
    g.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1))
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0, -76), 120)
    return g
  }, [])

  const dustUniforms = useMemo(
    () => ({ uTime: { value: 0 }, uColor: { value: new THREE.Color('#c9a87a') } }),
    []
  )

  const smokeUniforms = useMemo(
    () =>
      [0, 1].map((i) => ({
        uTime: { value: 0 },
        uSway: { value: 0.28 },
        uOpacity: { value: 0 },
        uSeed: { value: 5.1 + i * 2.9 },
        uColor: { value: new THREE.Color('#b09877') },
      })),
    []
  )

  useFrame((state) => {
    const t = state.clock.elapsedTime
    const { scroll } = getState()
    dustUniforms.uTime.value = t
    // roast-smoke wisps behind the hero bean, gone once it shatters
    const heroVis = (1 - seg(scroll, 0.1, 0.16)) * 0.35
    smokeUniforms.forEach((u) => {
      u.uTime.value = t
      u.uOpacity.value = heroVis
    })
  })

  return (
    <group>
      <points geometry={dustGeo} frustumCulled={false}>
        <shaderMaterial
          vertexShader={dustVertex}
          fragmentShader={dustFragment}
          uniforms={dustUniforms}
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>

      {/* smoke rising off the hero bean */}
      {smokeUniforms.map((u, i) => (
        <mesh key={i} position={[i === 0 ? -0.7 : 0.9, 2.2, -1.2]} rotation={[0, i * 0.9, 0]}>
          <planeGeometry args={[2.2, 4.4, 1, 24]} />
          <shaderMaterial
            vertexShader={steamVertex}
            fragmentShader={steamFragment}
            uniforms={u}
            transparent
            depthWrite={false}
            side={THREE.DoubleSide}
          />
        </mesh>
      ))}

      {/* base light: a warm key raking the hero, cold fill everywhere */}
      <ambientLight intensity={0.22} color="#8d7a63" />
      <directionalLight position={[4, 5, 6]} intensity={1.5} color="#f2ddba" />
      {/* Rim from behind-left. Without it the bean's dark side dissolves into
          a black background and the silhouette stops existing. */}
      <directionalLight position={[-5, 2.5, -4]} intensity={2.3} color="#ffb066" />
      <directionalLight position={[-1, -3, 3]} intensity={0.7} color="#7f93ad" />
      <pointLight position={[-3, -2, 2]} intensity={8} color="#e08b3c" distance={16} decay={2} />
      {/* a cool wash over the particle valley */}
      <pointLight position={[0, 10, -38]} intensity={30} color="#cfd6e0" distance={50} decay={1.8} />
    </group>
  )
}
