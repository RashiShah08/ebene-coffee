import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { makeCupGeometry, makeSaucerGeometry } from '../three/geometry'
import { ceramicMaps, cremaMap, timberMaps } from './materials'
import { steamVertex, steamFragment } from '../three/shaders'
import { getState } from '../store'
import { seg, WORLD } from './config'

/**
 * The last station: one cup, poured and steaming, floating in the dark.
 * The journey that started inside a bean ends at the counter.
 */
export function Finale() {
  const group = useRef(null)
  const steamMats = useRef([])

  const cupGeo = useMemo(() => makeCupGeometry('wide'), [])
  const saucerGeo = useMemo(() => makeSaucerGeometry(), [])
  const liquidGeo = useMemo(() => new THREE.CircleGeometry(0.56, 48), [])

  const steamUniforms = useMemo(
    () =>
      [0, 1, 2].map((i) => ({
        uTime: { value: 0 },
        uSway: { value: 0.16 + i * 0.05 },
        uOpacity: { value: 0 },
        uSeed: { value: i * 3.7 + 1.3 },
        uColor: { value: new THREE.Color('#d8c9b2') },
      })),
    []
  )

  useFrame((state) => {
    const { scroll } = getState()
    const t = state.clock.elapsedTime
    const vis = seg(scroll, 0.78, 0.84)
    // no idle spin — tables don't rotate, and realism lives on such details
    if (group.current) group.current.visible = vis > 0.01
    steamUniforms.forEach((u) => {
      u.uTime.value = t
      u.uOpacity.value = vis * 0.5
    })
  })

  const [fx, fy, fz] = WORLD.finale

  return (
    <group ref={group} position={[fx, fy, fz]}>
      {/* the counter it all lands on */}
      <mesh position={[0, -0.36, 0]}>
        <cylinderGeometry args={[4.6, 4.6, 0.6, 64]} />
        <meshPhysicalMaterial
          map={timberMaps().map}
          roughnessMap={timberMaps().rough}
          roughness={1}
          clearcoat={0.3}
          clearcoatRoughness={0.55}
          envMapIntensity={0.7}
        />
      </mesh>

      <mesh geometry={cupGeo} scale={1.9}>
        <meshPhysicalMaterial
          map={ceramicMaps().map}
          roughnessMap={ceramicMaps().rough}
          roughness={1}
          clearcoat={0.9}
          clearcoatRoughness={0.22}
          envMapIntensity={1.1}
        />
      </mesh>
      <mesh geometry={saucerGeo} scale={1.9} position={[0, -0.03, 0]}>
        <meshPhysicalMaterial
          map={ceramicMaps().map}
          roughnessMap={ceramicMaps().rough}
          roughness={1}
          clearcoat={0.9}
          clearcoatRoughness={0.22}
          envMapIntensity={1.1}
        />
      </mesh>
      <mesh geometry={liquidGeo} rotation={[-Math.PI / 2, 0, 0]} position={[0, 1.32, 0]} scale={1.9}>
        <meshPhysicalMaterial
          map={cremaMap()}
          roughness={0.06}
          clearcoat={1}
          clearcoatRoughness={0.05}
          envMapIntensity={1.6}
        />
      </mesh>

      {/* steam ribbons, slightly rotated copies so they read from any angle */}
      {steamUniforms.map((u, i) => (
        <mesh key={i} position={[0, 3.1, 0]} rotation={[0, (i / 3) * Math.PI, 0]}>
          <planeGeometry args={[1.7, 3.4, 1, 24]} />
          <shaderMaterial
            vertexShader={steamVertex}
            fragmentShader={steamFragment}
            uniforms={u}
            transparent
            depthWrite={false}
            side={THREE.DoubleSide}
          />
        </mesh>
      ))}

      <pointLight position={[2.5, 4, 3]} intensity={45} color="#f2ddba" distance={26} decay={1.8} />
      <pointLight position={[-5.5, 4.5, -4]} intensity={5} color="#e08b3c" distance={16} decay={2} />
    </group>
  )
}
