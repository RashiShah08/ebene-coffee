/* eslint-disable */
/**
 * Shaders specific to the journey: the morphing particle field, the ember
 * stream in the roaster tunnel, and the ambient dust corridor. The steam,
 * liquid and pour shaders live in ../three/shaders.js and are reused as-is.
 */

/* --------------------------------------------------- morphing bean field */
/* One particle system, three shapes. Each particle carries its position in
   every state; uPhase (0 bean → 1 debris → 2 terrain) blends between them
   with a per-particle stagger so the morphs ripple instead of tweening in
   lockstep. */

export const fieldVertex = /* glsl */ `
attribute vec3 aExplode;
attribute vec3 aTerrain;
attribute float aSeed;

uniform float uPhase;   // 0..2
uniform float uTime;
uniform float uSize;
uniform float uAlpha;

varying float vAlpha;
varying float vHeat;    // 0 = bean brown, 1 = ember hot
varying float vRidge;   // terrain altitude, for colouring the valley

float stagger(float t, float seed){
  // each particle starts a little late and finishes a little early
  float s = clamp(t * 1.5 - seed * 0.5, 0.0, 1.0);
  return s * s * (3.0 - 2.0 * s);
}

void main(){
  float t1 = clamp(uPhase, 0.0, 1.0);
  float t2 = clamp(uPhase - 1.0, 0.0, 1.0);

  float s1 = stagger(t1, aSeed);
  float s2 = stagger(t2, fract(aSeed * 7.31));

  vec3 p = mix(position, aExplode, s1);
  p = mix(p, aTerrain, s2);

  // free-floating wobble while airborne
  float drift = s1 * (1.0 - s2);
  p.x += sin(uTime * 0.7 + aSeed * 40.0) * 0.35 * drift;
  p.y += cos(uTime * 0.6 + aSeed * 31.0) * 0.30 * drift;
  p.z += sin(uTime * 0.5 + aSeed * 23.0) * 0.35 * drift;

  // settled terrain breathes very slightly, like heat haze
  p.y += sin(uTime * 0.8 + aSeed * 90.0) * 0.05 * s2;

  vHeat = drift * 0.7; // glowing-warm, not traffic-cone orange
  vRidge = aTerrain.y;

  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_Position = projectionMatrix * mv;

  float size = uSize * (0.5 + aSeed * 0.9);
  // Hard ceiling: debris and scree should read as grain, never as bokeh
  // blobs. At valley distance the unclamped size lands around 15px, so this
  // ceiling is doing all the work — raise it and the terrain turns to soup.
  gl_PointSize = clamp(size * (240.0 / max(1.0, -mv.z)), 1.0, 5.5);

  vAlpha = uAlpha;
}
`

export const fieldFragment = /* glsl */ `
varying float vAlpha;
varying float vHeat;
varying float vRidge;

uniform vec3 uBrown;
uniform vec3 uEmber;
uniform vec3 uCream;

void main(){
  vec2 c = gl_PointCoord - 0.5;
  float d = length(c);
  if (d > 0.5) discard;
  float a = smoothstep(0.5, 0.26, d) * vAlpha;
  if (a < 0.004) discard;

  // bean brown at rest, ember while flying, cream on the terrain ridgelines
  vec3 col = mix(uBrown, uEmber, vHeat);
  float ridge = smoothstep(-1.2, 2.6, vRidge) * (1.0 - vHeat);
  col = mix(col, uCream, ridge * 0.55);

  gl_FragColor = vec4(col, a);
}
`

/* ------------------------------------------------------------ ember stream */
/* Points inside the roaster tunnel that stream toward the camera. Additive,
   bright enough for bloom to catch. */

export const emberVertex = /* glsl */ `
attribute float aSeed;
uniform float uTime;
uniform float uSize;
varying float vAlpha;

void main(){
  vec3 p = position;
  float speed = 6.0 + aSeed * 9.0;
  float span = 40.0;
  // stream toward +z and wrap back to the far end of the tunnel
  p.z += mod(uTime * speed + aSeed * span, span);

  // swirl around the tunnel axis
  float ang = uTime * (0.4 + aSeed * 0.8) + aSeed * 40.0;
  p.x += sin(ang) * 0.35;
  p.y += cos(ang * 0.9) * 0.35;

  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_Position = projectionMatrix * mv;
  gl_PointSize = clamp(uSize * (0.4 + aSeed) * (200.0 / max(1.0, -mv.z)), 1.0, 18.0);

  // fade at both ends of the wrap so respawns never pop
  float life = mod(uTime * speed + aSeed * span, span) / span;
  vAlpha = smoothstep(0.0, 0.1, life) * (1.0 - smoothstep(0.75, 1.0, life));
}
`

export const emberFragment = /* glsl */ `
varying float vAlpha;
uniform vec3 uColor;
uniform float uIntensity;

void main(){
  vec2 c = gl_PointCoord - 0.5;
  float d = length(c);
  if (d > 0.5) discard;
  float a = smoothstep(0.5, 0.0, d) * vAlpha * uIntensity;
  gl_FragColor = vec4(uColor * (1.0 + a), a);
}
`

/* ------------------------------------------------------------------- dust */
/* Faint motes scattered down the whole corridor. They exist to sell the
   camera's motion — parallax needs something to slide past. */

export const dustVertex = /* glsl */ `
attribute float aSeed;
uniform float uTime;
varying float vAlpha;

void main(){
  vec3 p = position;
  p.x += sin(uTime * 0.2 + aSeed * 50.0) * 0.6;
  p.y += cos(uTime * 0.16 + aSeed * 70.0) * 0.5;

  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_Position = projectionMatrix * mv;
  gl_PointSize = clamp((1.5 + aSeed * 2.5) * (140.0 / max(1.0, -mv.z)), 0.5, 5.0);

  // twinkle
  vAlpha = 0.25 + 0.75 * abs(sin(uTime * (0.3 + aSeed) + aSeed * 20.0));
}
`

export const dustFragment = /* glsl */ `
varying float vAlpha;
uniform vec3 uColor;

void main(){
  vec2 c = gl_PointCoord - 0.5;
  float d = length(c);
  if (d > 0.5) discard;
  float a = smoothstep(0.5, 0.0, d) * vAlpha * 0.35;
  gl_FragColor = vec4(uColor, a);
}
`
