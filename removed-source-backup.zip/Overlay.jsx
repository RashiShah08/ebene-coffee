import { useEffect, useRef, useState } from 'react'
import { brand, hero, origin, roast, menu, visit, footer, order } from '../content'
import { useStore, getState } from '../store'
import { gbp, linePrice, takesMilk } from '../pricing'
import { getLenis } from '../hooks/useLenis'
import { CHAPTERS, chapter, seg } from '../journey/config'

/**
 * The caption layer. Every chapter is a fixed full-viewport <section> whose
 * opacity/transform are written directly from one rAF loop reading the store
 * — React only re-renders when a *discrete* value changes (active roast
 * level, active menu item), never per scroll frame.
 */

/** opacity envelope: ease in over the head of a chapter, out over the tail */
function envelope(p, c, holdStart = false, holdEnd = false) {
  const head = holdStart ? 1 : seg(p, c.start, c.start + (c.end - c.start) * 0.18)
  const tail = holdEnd ? 1 : 1 - seg(p, c.end - (c.end - c.start) * 0.14, c.end)
  return Math.min(head, tail)
}

export function Overlay() {
  const refs = useRef({})
  const shatterRef = useRef(null)
  const [roastIdx, setRoastIdx] = useState(0)
  const menuIdx = useStore((s) => s.menuIndex)

  useEffect(() => {
    let raf = 0
    let lastRoast = -1
    const loop = () => {
      const p = getState().scroll

      for (const c of CHAPTERS) {
        const el = refs.current[c.id]
        if (!el) continue
        const o = envelope(p, c, c.id === 'hero', c.id === 'visit')
        const lt = Math.min(1, Math.max(0, (p - c.start) / (c.end - c.start)))
        el.style.opacity = o.toFixed(3)
        el.style.visibility = o < 0.01 ? 'hidden' : 'visible'
        el.style.transform = `translateY(${((0.5 - lt) * 46).toFixed(1)}px)`
        el.dataset.active = o > 0.4 ? 'true' : 'false'
      }

      // the shatter headline pulls itself apart as the bean does
      if (shatterRef.current) {
        const t = seg(p, 0.12, 0.24)
        shatterRef.current.style.letterSpacing = `${(t * 0.28).toFixed(3)}em`
      }

      // roast level follows depth in the tunnel: deeper = darker
      const rc = chapter('roast')
      const rl = Math.min(1, Math.max(0, (p - rc.start) / (rc.end - rc.start)))
      const ri = Math.min(roast.levels.length - 1, Math.floor(rl * roast.levels.length))
      if (ri !== lastRoast) {
        lastRoast = ri
        setRoastIdx(ri)
      }

      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [])

  const reg = (id) => (el) => (refs.current[id] = el)
  const level = roast.levels[roastIdx]

  return (
    <div className="overlay">
      {/* ------------------------------------------------ 01 · hero */}
      <section className="ch ch--hero" ref={reg('hero')}>
        <p className="eyebrow">{hero.eyebrow}</p>
        <h1 className="mega">
          <span className="mega__line">{brand.name}</span>
          <span className="mega__sub">
            {hero.titleLines.join(' ')} · EST. {brand.est}
          </span>
        </h1>
        <p className="ch__body ch__body--hero">{hero.body}</p>
        <div className="scrollcue">
          <span className="scrollcue__tick" />
          <span>Scroll to descend into the bean</span>
        </div>
      </section>

      {/* --------------------------------------------- 02 · shatter */}
      <section className="ch ch--shatter" ref={reg('shatter')}>
        <h2 className="mega mega--center" ref={shatterRef}>
          <span className="mega__line">TWELVE KILOS</span>
          <span className="mega__line">AT A TIME</span>
        </h2>
        <p className="ch__body ch__body--center">Logged to the second. Pulled to a curve.</p>
      </section>

      {/* ---------------------------------------------- 03 · origin */}
      <section className="ch ch--origin" ref={reg('origin')}>
        <p className="index">01 · {origin.label}</p>
        <h2 className="big">{origin.title.replace('\n', ' ')}</h2>
        <div className="regions">
          {origin.regions.map((r) => (
            <article className="region" key={r.id} style={{ '--swatch': r.swatch }}>
              <h3>
                {r.name} <span>{r.country}</span>
              </h3>
              <p className="mono">
                {r.coords} · {r.altitude}
              </p>
              <p className="mono dim">{r.process}</p>
              <p className="notes">{r.notes.join(' · ')}</p>
            </article>
          ))}
        </div>
      </section>

      {/* ----------------------------------------------- 04 · roast */}
      <section className="ch ch--roast" ref={reg('roast')}>
        <p className="index">02 · {roast.label} — deeper is darker</p>
        <div className="roast__readout" key={level.name}>
          <span className="roast__temp">{level.temp}</span>
          <h2 className="big">{level.name}</h2>
          <p className="mono">
            Agtron {level.agtron} · {level.time}
          </p>
          <p className="notes">{level.notes.join(' · ')}</p>
          <p className="ch__body">{level.body}</p>
        </div>
        <div className="roast__detents">
          {roast.levels.map((l, i) => (
            <span key={l.name} data-on={i <= roastIdx} style={{ '--c': l.color }} />
          ))}
        </div>
      </section>

      {/* ------------------------------------------------ 05 · menu */}
      <section className="ch ch--menu" ref={reg('menu')}>
        <p className="index">
          03 · {menu.label} — {String(menuIdx + 1).padStart(2, '0')}/{String(menu.items.length).padStart(2, '0')}
        </p>
        <MenuCard idx={menuIdx} />
      </section>

      {/* ------------------------------------------------ 06 · pour */}
      <section className="ch ch--pour" ref={reg('pour')}>
        <h2 className="mega mega--center">
          <span className="mega__line">POUR</span>
        </h2>
      </section>

      {/* ----------------------------------------------- 07 · visit */}
      <section className="ch ch--visit" ref={reg('visit')}>
        <p className="index">04 · {visit.label}</p>
        <h2 className="big">{visit.title}</h2>

        <div className="visit__grid">
          <div>
            <p className="label">Address</p>
            {visit.address.map((l) => (
              <p key={l}>{l}</p>
            ))}
            <p className="mono dim">{visit.coords}</p>
          </div>
          <div>
            <p className="label">Hours</p>
            {visit.hours.map((h) => (
              <p className="visit__hours" key={h.day}>
                <span>{h.day}</span>
                <span className="mono">{h.label}</span>
              </p>
            ))}
          </div>
          <div>
            <p className="label">Contact</p>
            <p>{visit.phone}</p>
            <p>{visit.email}</p>
            <p className="mono dim">{visit.note}</p>
          </div>
        </div>

        <Newsletter />

        <footer className="endcap">
          <button
            className="btn btn--ghost"
            onClick={() => getLenis()?.scrollTo(0, { duration: 3 })}
          >
            ↑ Fly back to the bean
          </button>
          <p className="mono dim">{footer.legal}</p>
          <p className="mono dim">{footer.credit}</p>
        </footer>
      </section>
    </div>
  )
}

/** The orderable drink card for whichever cup faces the camera. */
function MenuCard({ idx }) {
  const item = menu.items[idx]
  const addToCart = useStore((s) => s.addToCart)
  const [size, setSize] = useState('single')
  const [milk, setMilk] = useState('whole')

  const milky = takesMilk(item.kind)
  const effMilk = milky ? milk : 'none'
  const unit = linePrice(item.price, size, effMilk)

  const add = () =>
    addToCart({
      name: item.name,
      kind: item.kind,
      size,
      sizeLabel: order.sizes.find((s) => s.id === size)?.label,
      milk: effMilk,
      milkLabel: milky ? order.milks.find((m) => m.id === milk)?.label : '',
      unit,
    })

  return (
    <div className="mcard" key={item.name}>
      <div className="mcard__head">
        <h2 className="big big--item">{item.name}</h2>
        {item.tag && <span className="tag">{item.tag}</span>}
      </div>
      <p className="mono">{item.spec}</p>
      <p className="ch__body">{item.desc}</p>

      <div className="mcard__row">
        <div className="chips">
          {order.sizes.map((s) => (
            <button key={s.id} className="chip" data-on={s.id === size} onClick={() => setSize(s.id)}>
              {s.label}
            </button>
          ))}
        </div>
        {milky && (
          <div className="chips">
            {order.milks.map((m) => (
              <button key={m.id} className="chip" data-on={m.id === milk} onClick={() => setMilk(m.id)}>
                {m.label}
              </button>
            ))}
          </div>
        )}
      </div>

      <button className="btn mcard__add" onClick={add}>
        Add — £{gbp(unit)}
      </button>
    </div>
  )
}

function Newsletter() {
  const [done, setDone] = useState(false)
  return (
    <form
      className="news"
      onSubmit={(e) => {
        e.preventDefault()
        setDone(true)
      }}
    >
      <p className="label">{footer.newsletter.title}</p>
      {done ? (
        <p className="news__done">{footer.newsletter.success}</p>
      ) : (
        <div className="news__row">
          <input type="email" required placeholder={footer.newsletter.placeholder} aria-label="Email" />
          <button className="btn" type="submit">
            {footer.newsletter.cta}
          </button>
        </div>
      )}
    </form>
  )
}
